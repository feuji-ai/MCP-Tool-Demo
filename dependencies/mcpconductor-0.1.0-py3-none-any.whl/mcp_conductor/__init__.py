"""
mcp_conductor - MCP Tool Integration Library

A comprehensive library for integrating MCP (Model Context Protocol) tools
with language models, focusing on reliable session management and
enterprise-ready agent frameworks.

Enhanced with built-in streaming display and flexible configuration for custom observability.
"""

# Core utilities
from mcp_conductor.core.logging import get_logger, logger, set_debug, MCP_CONDUCTOR_DEBUG
from mcp_conductor.core.utils import singleton
from mcp_conductor.core.exceptions import format_error

# Observability
from mcp_conductor.observability.observability import langfuse, langfuse_handler

# Connection management
from mcp_conductor.managers import ConnectionManager, StdioConnectionManager
from mcp_conductor.connectors import BaseConnector, StdioConnector

# Session management
from mcp_conductor.sessions import MCPSession

# Tool adaptation
from mcp_conductor.adapters import ToolAdapter

# Client orchestration
from mcp_conductor.clients import MCPClient

# Agent implementations
from mcp_conductor.agents import (
    Agent,
    LangGraphAgent,
    AgentConfigurationProvider,
    DefaultConfigurationProvider,
    StreamDisplayMode,
    StreamingFormatter
)

__version__ = "0.1.0"
__author__ = "MCP Conductor Team"

__all__ = [
    # Core utilities
    "get_logger",
    "logger",
    "set_debug",
    "MCP_CONDUCTOR_DEBUG",
    "singleton",
    "format_error",

    # Observability
    "langfuse",
    "langfuse_handler",

    # Connection infrastructure
    "ConnectionManager",
    "StdioConnectionManager",
    "BaseConnector",
    "StdioConnector",

    # Session management
    "MCPSession",

    # Tool adaptation
    "ToolAdapter",

    # Client orchestration
    "MCPClient",

    # Agent implementations
    "Agent",
    "LangGraphAgent",

    # Agent configuration
    "AgentConfigurationProvider",
    "DefaultConfigurationProvider",

    # Streaming display
    "StreamDisplayMode",
    "StreamingFormatter",
]