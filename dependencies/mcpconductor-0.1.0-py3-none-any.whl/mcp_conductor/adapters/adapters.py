"""
Tool adapters for converting MCP tools to different frameworks.

This module provides adapters for converting MCP tools to LangChain tools,
following mcp_use patterns exactly for reliable tool execution.
"""

import re
from typing import Any, NoReturn

from jsonschema_pydantic import jsonschema_to_pydantic
from langchain_core.tools import BaseTool, ToolException
from mcp.types import (
    CallToolResult,
    EmbeddedResource,
    ImageContent,
    Prompt,
    ReadResourceRequestParams,
    Resource,
    TextContent,
)
from pydantic import BaseModel, Field, create_model

from mcp_conductor.core.exceptions import format_error
from mcp_conductor.core.logging import logger
from mcp_conductor.sessions.session import MCPSession


class ToolAdapter:
    """Adapter for converting MCP tools to LangChain tools.

    Follows mcp_use patterns exactly for dynamic tool creation and result parsing.
    """

    def __init__(self, disallowed_tools: list[str] | None = None):
        """Initialize a new tool adapter.

        Args:
            disallowed_tools: list of tool names that should not be available.
        """
        self.disallowed_tools = disallowed_tools or []
        self._session_tool_map: dict[MCPSession, list[BaseTool]] = {}

    def fix_schema(self, schema: dict) -> dict:
        """Convert JSON Schema 'type': ['string', 'null'] to 'anyOf' format.

        Args:
            schema: The JSON schema to fix.

        Returns:
            The fixed JSON schema.
        """
        if isinstance(schema, dict):
            if "type" in schema and isinstance(schema["type"], list):
                schema["anyOf"] = [{"type": t} for t in schema["type"]]
                del schema["type"]  # Remove 'type' and standardize to 'anyOf'
            for key, value in schema.items():
                schema[key] = self.fix_schema(value)  # Apply recursively
        return schema

    async def create_tools_from_client(self, client) -> list[BaseTool]:
        """Create tools from an MCPClient instance."""
        # Get all active sessions
        sessions = client.get_all_active_sessions()

        # Extract all tools from all sessions
        all_tools = []
        for session in sessions.values():
            session_tools = await self.create_tools(session)
            all_tools.extend(session_tools)

        return all_tools

    def _parse_mcp_tool_result(self, tool_result: CallToolResult) -> str:
        """Parse the content of a CallToolResult into a string.

        Args:
            tool_result: The result object from calling an MCP tool.

        Returns:
            A string representation of the tool result content.

        Raises:
            ToolException: If the tool execution failed, returned no content,
                        or contained unexpected content types.
        """
        if tool_result.isError:
            raise ToolException(f"Tool execution failed: {tool_result.content}")

        if not tool_result.content:
            raise ToolException("Tool execution returned no content")

        decoded_result = ""
        for item in tool_result.content:
            match item.type:
                case "text":
                    item: TextContent
                    decoded_result += item.text
                case "image":
                    item: ImageContent
                    decoded_result += item.data  # Assuming data is string-like or base64
                case "resource":
                    resource: EmbeddedResource = item.resource
                    if hasattr(resource, "text"):
                        decoded_result += resource.text
                    elif hasattr(resource, "blob"):
                        # Assuming blob needs decoding or specific handling; adjust as needed
                        decoded_result += (
                            resource.blob.decode() if isinstance(resource.blob, bytes) else str(resource.blob)
                        )
                    else:
                        raise ToolException(f"Unexpected resource type: {resource.type}")
                case _:
                    raise ToolException(f"Unexpected content type: {item.type}")

        return decoded_result

    def _convert_tool(self, mcp_tool: dict[str, Any], session: MCPSession) -> BaseTool:
        """Convert an MCP tool to LangChain's tool format.

        Args:
            mcp_tool: The MCP tool to convert.
            session: The session that provides this tool.

        Returns:
            A LangChain BaseTool.
        """
        # Skip disallowed tools
        if mcp_tool.name in self.disallowed_tools:
            return None

        # This is a dynamic class creation, we need to work with the self reference
        adapter_self = self

        class McpToLangChainAdapter(BaseTool):
            name: str = mcp_tool.name or "NO NAME"
            description: str = mcp_tool.description or ""
            # Convert JSON schema to Pydantic model for argument validation
            args_schema: type[BaseModel] = jsonschema_to_pydantic(
                adapter_self.fix_schema(mcp_tool.inputSchema)  # Apply schema conversion
            )
            tool_session: MCPSession = session  # Use session instead of connector
            handle_tool_error: bool = True

            def __repr__(self) -> str:
                return f"MCP tool: {self.name}: {self.description}"

            def _run(self, **kwargs: Any) -> NoReturn:
                """Synchronous run method that always raises an error.

                Raises:
                    NotImplementedError: Always raises this error because MCP tools
                        only support async operations.
                """
                raise NotImplementedError("MCP tools only support async operations")

            async def _arun(self, **kwargs: Any) -> Any:
                """Asynchronously execute the tool with given arguments.

                Args:
                    kwargs: The arguments to pass to the tool.

                Returns:
                    The result of the tool execution.

                Raises:
                    ToolException: If tool execution fails.
                """
                logger.debug(f'MCP tool: "{self.name}" received input: {kwargs}')

                try:
                    tool_result: CallToolResult = await self.tool_session.call_tool(self.name, kwargs)
                    try:
                        # Use the helper function to parse the result
                        return adapter_self._parse_mcp_tool_result(tool_result)
                    except Exception as e:
                        # Log the exception for debugging
                        logger.error(f"Error parsing tool result: {e}")
                        return format_error(e, tool=self.name, tool_content=tool_result.content)

                except Exception as e:
                    if self.handle_tool_error:
                        return format_error(e, tool=self.name)  # Format the error to make LLM understand it
                    raise

        return McpToLangChainAdapter()

    def _convert_resource(self, mcp_resource: Resource, session: MCPSession) -> BaseTool:
        """Convert an MCP resource to LangChain's tool format.

        Each resource becomes an async tool that returns its content when called.
        The tool takes **no** arguments because the resource URI is fixed.
        """

        def _sanitize(name: str) -> str:
            return re.sub(r"[^A-Za-z0-9_]+", "_", name).lower().strip("_")

        class ResourceTool(BaseTool):
            name: str = _sanitize(mcp_resource.name or f"resource_{mcp_resource.uri}")
            description: str = (
                    mcp_resource.description or f"Return the content of the resource located at URI {mcp_resource.uri}."
            )
            args_schema: type[BaseModel] = ReadResourceRequestParams
            tool_session: MCPSession = session
            handle_tool_error: bool = True

            def _run(self, **kwargs: Any) -> NoReturn:
                raise NotImplementedError("Resource tools only support async operations")

            async def _arun(self, **kwargs: Any) -> Any:
                logger.debug(f'Resource tool: "{self.name}" called')
                try:
                    result = await self.tool_session.read_resource(mcp_resource.uri)
                    for content in result.contents:
                        # Attempt to decode bytes if necessary
                        if isinstance(content, bytes):
                            content_decoded = content.decode()
                        else:
                            content_decoded = str(content)

                    return content_decoded
                except Exception as e:
                    if self.handle_tool_error:
                        return format_error(e, tool=self.name)  # Format the error to make LLM understand it
                    raise

        return ResourceTool()

    def _convert_prompt(self, mcp_prompt: Prompt, session: MCPSession) -> BaseTool:
        """Convert an MCP prompt to LangChain's tool format.

        The resulting tool executes `get_prompt` on the session with the prompt's name and
        the user-provided arguments (if any). The tool returns the decoded prompt content.
        """
        prompt_arguments = mcp_prompt.arguments

        # Sanitize the prompt name to create a valid Python identifier for the model name
        base_model_name = re.sub(r"[^a-zA-Z0-9_]", "_", mcp_prompt.name)
        if not base_model_name or base_model_name[0].isdigit():
            base_model_name = "PromptArgs_" + base_model_name
        dynamic_model_name = f"{base_model_name}_InputSchema"

        if prompt_arguments:
            field_definitions_for_create: dict[str, Any] = {}
            for arg in prompt_arguments:
                param_type: type = getattr(arg, "type", str)
                if arg.required:
                    field_definitions_for_create[arg.name] = (
                        param_type,
                        Field(description=arg.description),
                    )
                else:
                    field_definitions_for_create[arg.name] = (
                        param_type | None,
                        Field(None, description=arg.description),
                    )

            InputSchema = create_model(dynamic_model_name, **field_definitions_for_create, __base__=BaseModel)
        else:
            # Create an empty Pydantic model if there are no arguments
            InputSchema = create_model(dynamic_model_name, __base__=BaseModel)

        class PromptTool(BaseTool):
            name: str = mcp_prompt.name
            description: str = mcp_prompt.description

            args_schema: type[BaseModel] = InputSchema
            tool_session: MCPSession = session
            handle_tool_error: bool = True

            def _run(self, **kwargs: Any) -> NoReturn:
                raise NotImplementedError("Prompt tools only support async operations")

            async def _arun(self, **kwargs: Any) -> Any:
                logger.debug(f'Prompt tool: "{self.name}" called with args: {kwargs}')
                try:
                    result = await self.tool_session.get_prompt(self.name, kwargs)
                    return result.messages
                except Exception as e:
                    if self.handle_tool_error:
                        return format_error(e, tool=self.name)  # Format the error to make LLM understand it
                    raise

        return PromptTool()

    async def create_tools(self, session: MCPSession) -> list[BaseTool]:
        """Create LangChain tools from an MCP session.

        Args:
            session: The MCP session to extract tools from.

        Returns:
            A list of LangChain BaseTool instances.
        """
        # Check if we already have tools for this session
        if session in self._session_tool_map:
            logger.debug(f"Returning {len(self._session_tool_map[session])} existing tools for session")
            return self._session_tool_map[session]

        # Ensure session is connected and initialized
        if not session.is_connected:
            await session.connect()
        if session.session_info is None:
            await session.initialize()

        session_tools = []

        # Convert MCP tools
        tools = await session.list_tools()
        for tool in tools:
            converted_tool = self._convert_tool(tool, session)
            if converted_tool:
                session_tools.append(converted_tool)

        # Convert resources to tools
        resources = await session.list_resources()
        for resource in resources:
            converted_resource = self._convert_resource(resource, session)
            if converted_resource:
                session_tools.append(converted_resource)

        # Convert prompts to tools
        prompts = await session.list_prompts()
        for prompt in prompts:
            converted_prompt = self._convert_prompt(prompt, session)
            if converted_prompt:
                session_tools.append(converted_prompt)

        # Store the tools for this session
        self._session_tool_map[session] = session_tools

        # Log available tools for debugging
        logger.debug(
            f"Created {len(session_tools)} tools for session: "
            f"{[tool.name for tool in session_tools]}"
        )

        return session_tools

    async def load_tools_for_session(self, session: MCPSession) -> list[BaseTool]:
        """Dynamically load tools for a specific session.

        Args:
            session: The session to load tools for.

        Returns:
            The list of tools that were loaded in LangChain format.
        """
        return await self.create_tools(session)