# 🔧 MCP Conductor Adapters

**Tool Conversion Engine - Bridging MCP Tools with LangChain Framework**

The `adapters` module is the **"universal translator"** that converts MCP (Model Context Protocol) tools into LangChain-compatible tools. Think of it as the **"adapter cable"** that lets you plug any MCP server into your AI agents seamlessly.

## 📁 Folder Structure

```
mcp_conductor/adapters/
├── README.md                   # This documentation
├── __init__.py                 # Module exports
└── adapters.py                 # Main tool conversion engine
```

## 🎯 What Do Adapters Actually Do?

### **Simple Analogy: Universal Power Adapter**

When you travel internationally, you need adapters for your electronics:

```
🔌 US Plug (Your Device) → 🔄 Universal Adapter → 🔌 European Socket (Foreign Outlet)
```

**Adapters in MCP Conductor work the same way**:

```
🛠️ MCP Tool → 🔄 ToolAdapter → 🤖 LangChain Agent
   (Browser     (Converts        (AI Agent
    Automation)  Format)          Ready)
```

**Without Adapters**:
```
AI Agent: "I want to click a button"
MCP Tool: "I speak MCP protocol with JSON schemas"
AI Agent: "I don't understand that format" ❌
```

**With Adapters**:
```
AI Agent: "I want to click a button"
Adapter: "Let me translate that for you..."
MCP Tool: "JSON schema converted to Pydantic model" ✅
Adapter: "Here's a LangChain tool the agent can use!"
AI Agent: "Perfect! *clicks button*" ✅
```

## 🏗️ Architecture Overview

```mermaid
graph TB
    subgraph "MCP Ecosystem"
        A[Playwright MCP Server] --> D[MCP Tools]
        B[Filesystem MCP Server] --> E[MCP Resources] 
        C[Custom MCP Server] --> F[MCP Prompts]
    end
    
    subgraph "Adapter Engine"
        D --> G[Tool Converter]
        E --> H[Resource Converter]
        F --> I[Prompt Converter]
        
        G --> J[Schema Conversion<br/>JSON → Pydantic]
        H --> J
        I --> J
        
        J --> K[Result Parser<br/>MCP → String]
        K --> L[Error Handler<br/>LLM-Friendly]
    end
    
    subgraph "LangChain Integration"
        L --> M[LangChain BaseTool]
        M --> N[AI Agent]
        N --> O[Tool Execution]
        O --> P[Parsed Results]
    end
    
    style G fill:#ff9800,color:#fff
    style J fill:#2196f3,color:#fff
    style M fill:#4caf50,color:#fff
    style N fill:#9c27b0,color:#fff
```

## 📄 File Documentation

### `__init__.py` - Module Exports

**Purpose**: Clean API for importing adapter functionality.

```python
from mcp_conductor.adapters.adapters import ToolAdapter

__all__ = [
    "ToolAdapter",
]
```

**Usage**:
```python
from mcp_conductor.adapters import ToolAdapter
```

---

### `adapters.py` - Tool Conversion Engine ⭐

**Purpose**: The heart of MCP → LangChain conversion with intelligent schema handling and error management.

#### 🎯 Core Responsibilities

1. **🔄 Tool Conversion**
   - MCP tools → LangChain BaseTool
   - Async execution wrapper
   - Parameter validation
   - Result parsing

2. **📋 Schema Conversion** 
   - JSON Schema → Pydantic models
   - Type safety enforcement
   - Dynamic model creation
   - Schema fixing for compatibility

3. **📄 Multi-Format Support**
   - **Tools**: Direct function calls
   - **Resources**: File/data access
   - **Prompts**: Template execution

4. **🛡️ Error Handling**
   - LLM-friendly error messages
   - Graceful failure modes
   - Retry logic support
   - Debug information

## 🔍 Core Classes & Methods

### **ToolAdapter Class**

```python
class ToolAdapter:
    """Main adapter for converting MCP components to LangChain tools."""
    
    def __init__(self, disallowed_tools: list[str] | None = None):
        """Initialize with optional tool filtering."""
        self.disallowed_tools = disallowed_tools or []
        self._session_tool_map: dict[MCPSession, list[BaseTool]] = {}
```

#### **Key Methods**:

**1. Schema Fixing**
```python
def fix_schema(self, schema: dict) -> dict:
    """Convert problematic JSON Schema formats to standard ones."""
    # Converts: {"type": ["string", "null"]} 
    # To:       {"anyOf": [{"type": "string"}, {"type": "null"}]}
```

**2. Tool Creation from Clients**
```python
async def create_tools_from_client(self, client) -> list[BaseTool]:
    """Extract all tools from all active MCP sessions."""
    sessions = client.get_all_active_sessions()
    all_tools = []
    for session in sessions.values():
        session_tools = await self.create_tools(session)
        all_tools.extend(session_tools)
    return all_tools
```

**3. Result Parsing**
```python
def _parse_mcp_tool_result(self, tool_result: CallToolResult) -> str:
    """Parse MCP tool results into LLM-readable strings."""
    # Handles: text, image, resource, error content
    # Returns: Clean string representation
```

## 🚀 Conversion Types

### **1. Tool Conversion** 🛠️

**MCP Tool → LangChain Tool**

```python
# Original MCP Tool
{
    "name": "playwright_click",
    "description": "Click on an element by CSS selector",
    "inputSchema": {
        "type": "object",
        "properties": {
            "selector": {"type": "string", "description": "CSS selector"}
        },
        "required": ["selector"]
    }
}

# Converted LangChain Tool
class McpToLangChainAdapter(BaseTool):
    name: str = "playwright_click"
    description: str = "Click on an element by CSS selector"
    args_schema: PlaywrightClickInput  # Auto-generated Pydantic model
    
    async def _arun(self, selector: str) -> str:
        result = await self.tool_session.call_tool("playwright_click", {"selector": selector})
        return self._parse_result(result)
```

### **2. Resource Conversion** 📄

**MCP Resource → LangChain Tool**

```python
# MCP Resource
{
    "uri": "file:///workspace/config.json",
    "name": "app_config", 
    "description": "Application configuration file"
}

# Converted Tool
class ResourceTool(BaseTool):
    name: str = "read_app_config"
    description: str = "Return the content of the application configuration file"
    
    async def _arun(self) -> str:
        result = await self.tool_session.read_resource("file:///workspace/config.json")
        return result.content
```

### **3. Prompt Conversion** 💬

**MCP Prompt → LangChain Tool**

```python
# MCP Prompt
{
    "name": "code_review",
    "description": "Generate code review template",
    "arguments": [
        {"name": "language", "type": "string", "required": true},
        {"name": "complexity", "type": "string", "required": false}
    ]
}

# Converted Tool  
class PromptTool(BaseTool):
    name: str = "code_review"
    description: str = "Generate code review template"
    args_schema: CodeReviewInput  # Generated with language, complexity fields
    
    async def _arun(self, language: str, complexity: str = None) -> str:
        result = await self.tool_session.get_prompt("code_review", {
            "language": language, "complexity": complexity
        })
        return result.messages
```

## 🔧 Schema Conversion Deep Dive

### **Problem: JSON Schema Incompatibilities**

Many MCP servers use JSON schemas that aren't directly compatible with Pydantic:

```python
# Problematic Schema (common in MCP servers)
{
    "type": ["string", "null"],  # Array of types - not standard
    "properties": {
        "value": {"type": ["number", "string"]}
    }
}

# Fixed Schema (Pydantic compatible)
{
    "anyOf": [
        {"type": "string"}, 
        {"type": "null"}
    ],
    "properties": {
        "value": {
            "anyOf": [
                {"type": "number"}, 
                {"type": "string"}
            ]
        }
    }
}
```

### **Solution: Smart Schema Fixing**

```python
def fix_schema(self, schema: dict) -> dict:
    """Recursively fix schema compatibility issues."""
    if isinstance(schema, dict):
        if "type" in schema and isinstance(schema["type"], list):
            # Convert type arrays to anyOf format
            schema["anyOf"] = [{"type": t} for t in schema["type"]]
            del schema["type"]
        
        # Apply recursively to nested properties
        for key, value in schema.items():
            schema[key] = self.fix_schema(value)
    
    return schema
```

## 🛡️ Error Handling & Result Parsing

### **LLM-Friendly Error Messages**

```python
# Raw MCP Error
CallToolResult(
    isError=True, 
    content=[{"type": "text", "text": "Connection timeout after 30s"}]
)

# Adapter-Processed Error  
{
    "error": "TimeoutError",
    "details": "Connection timeout after 30s", 
    "isRetryable": True,
    "code": "TIMEOUT",
    "tool": "playwright_navigate"
}
```

### **Multi-Format Result Parsing**

```python
def _parse_mcp_tool_result(self, tool_result: CallToolResult) -> str:
    """Handle different MCP result types."""
    
    if tool_result.isError:
        raise ToolException(f"Tool execution failed: {tool_result.content}")
    
    decoded_result = ""
    for item in tool_result.content:
        match item.type:
            case "text":
                decoded_result += item.text
            case "image": 
                decoded_result += f"[Image: {item.data[:100]}...]"
            case "resource":
                if hasattr(item.resource, "text"):
                    decoded_result += item.resource.text
                else:
                    decoded_result += f"[Binary Resource: {len(item.resource.blob)} bytes]"
    
    return decoded_result
```

## 🚀 Usage Examples

### **Basic Tool Conversion**

```python
from mcp_conductor.adapters import ToolAdapter
from mcp_conductor.sessions import MCPSession

# Create adapter
adapter = ToolAdapter()

# Convert tools from a session
session = MCPSession(stdio_connector)
await session.initialize()

langchain_tools = await adapter.create_tools(session)
print(f"Converted {len(langchain_tools)} MCP tools to LangChain format")

# Use with an agent
agent = LangGraphAgent(llm=llm, tools=langchain_tools)
```

### **Multi-Session Tool Aggregation**

```python
from mcp_conductor.clients import MCPClient

# Multiple MCP servers
client = MCPClient.from_dict({
    "mcpServers": {
        "browser": {"command": "npx", "args": ["@playwright/mcp"]},
        "files": {"command": "npx", "args": ["@modelcontextprotocol/server-filesystem", "/tmp"]},
        "git": {"command": "python", "args": ["-m", "mcp_git", "/repo"]}
    }
})

await client.create_all_sessions()

# Adapter aggregates tools from all sessions
adapter = ToolAdapter()
all_tools = await adapter.create_tools_from_client(client)

print("Available tools:")
for tool in all_tools:
    print(f"  - {tool.name}: {tool.description}")
```

### **Tool Filtering**

```python
# Exclude dangerous or administrative tools
adapter = ToolAdapter(disallowed_tools=[
    "filesystem_delete",
    "system_shutdown", 
    "admin_reset"
])

safe_tools = await adapter.create_tools(session)
# Only safe tools are converted
```

### **Custom Error Handling**

```python
class CustomToolAdapter(ToolAdapter):
    def _parse_mcp_tool_result(self, tool_result: CallToolResult) -> str:
        """Custom result parsing with business logic."""
        
        if tool_result.isError:
            # Custom error handling
            error_msg = tool_result.content[0].text
            if "permission denied" in error_msg.lower():
                return "❌ Access denied. Please check your permissions."
            elif "timeout" in error_msg.lower():
                return "⏰ Operation timed out. The server may be busy."
            else:
                return f"🔧 Tool error: {error_msg}"
        
        # Custom success formatting
        result = super()._parse_mcp_tool_result(tool_result)
        return f"✅ Success: {result}"
```

## 🎯 Real-World Conversion Examples

### **Example 1: Browser Automation Tools**

**Input - Playwright MCP Tools**:
```json
[
  {
    "name": "playwright_navigate",
    "description": "Navigate to a URL and wait for the page to load",
    "inputSchema": {
      "type": "object", 
      "properties": {
        "url": {"type": "string", "description": "The URL to navigate to"}
      },
      "required": ["url"]
    }
  },
  {
    "name": "playwright_click",  
    "description": "Click on an element identified by a CSS selector",
    "inputSchema": {
      "type": "object",
      "properties": {
        "selector": {"type": "string", "description": "CSS selector for the element"}
      },
      "required": ["selector"]
    }
  }
]
```

**Output - LangChain Tools**:
```python
# Generated LangChain tools
[
    McpToLangChainAdapter(
        name="playwright_navigate",
        description="Navigate to a URL and wait for the page to load",
        args_schema=PlaywrightNavigateInput,  # Auto-generated Pydantic model
        tool_session=session
    ),
    McpToLangChainAdapter(
        name="playwright_click", 
        description="Click on an element identified by a CSS selector",
        args_schema=PlaywrightClickInput,   # Auto-generated Pydantic model
        tool_session=session
    )
]
```

### **Example 2: File System Resources**

**Input - MCP Resources**:
```json
[
  {
    "uri": "file:///workspace/package.json",
    "name": "package_config",
    "description": "Node.js package configuration"
  },
  {
    "uri": "file:///workspace/README.md", 
    "name": "project_readme",
    "description": "Project documentation"
  }
]
```

**Output - Resource Tools**:
```python
[
    ResourceTool(
        name="read_package_config",
        description="Return the content of the Node.js package configuration",
        tool_session=session
    ),
    ResourceTool(
        name="read_project_readme",
        description="Return the content of the project documentation", 
        tool_session=session
    )
]
```

### **Example 3: Code Generation Prompts**

**Input - MCP Prompts**:
```json
[
  {
    "name": "generate_test",
    "description": "Generate unit test template",
    "arguments": [
      {"name": "function_name", "type": "string", "required": true},
      {"name": "test_framework", "type": "string", "required": false, "description": "pytest, unittest, etc."}
    ]
  }
]
```

**Output - Prompt Tools**:
```python
[
    PromptTool(
        name="generate_test",
        description="Generate unit test template",
        args_schema=GenerateTestInput,  # Dynamic model with function_name, test_framework
        tool_session=session
    )
]
```

## 🔧 Advanced Features

### **Session-Based Tool Caching**

```python
class ToolAdapter:
    def __init__(self):
        self._session_tool_map: dict[MCPSession, list[BaseTool]] = {}
    
    async def create_tools(self, session: MCPSession) -> list[BaseTool]:
        # Check cache first
        if session in self._session_tool_map:
            return self._session_tool_map[session]
        
        # Convert and cache
        tools = await self._convert_session_tools(session)
        self._session_tool_map[session] = tools
        return tools
```

### **Dynamic Tool Loading**

```python
async def load_tools_for_session(self, session: MCPSession) -> list[BaseTool]:
    """Dynamically load tools when server capabilities change."""
    
    # Re-discover tools (bypasses cache)
    await session.initialize()  # Refresh capabilities
    
    # Convert fresh tool list
    new_tools = await self.create_tools(session)
    
    # Update cache
    self._session_tool_map[session] = new_tools
    
    return new_tools
```

### **Type-Safe Tool Execution**

```python
# Generated Pydantic model ensures type safety
class PlaywrightClickInput(BaseModel):
    selector: str = Field(description="CSS selector for the element")
    
    # Validation happens automatically
    @validator("selector")
    def validate_selector(cls, v):
        if not v.strip():
            raise ValueError("Selector cannot be empty")
        return v
```

## 🧪 Testing Adapters

### **Unit Test Example**

```python
async def test_tool_conversion():
    # Mock MCP tool
    mcp_tool = {
        "name": "test_tool",
        "description": "A test tool",
        "inputSchema": {
            "type": "object",
            "properties": {"param": {"type": "string"}},
            "required": ["param"]
        }
    }
    
    adapter = ToolAdapter()
    session = MockMCPSession()
    
    # Convert to LangChain tool
    langchain_tool = adapter._convert_tool(mcp_tool, session)
    
    # Verify conversion
    assert langchain_tool.name == "test_tool"
    assert langchain_tool.description == "A test tool"
    assert hasattr(langchain_tool.args_schema, "param")
    
    # Test execution
    result = await langchain_tool._arun(param="test_value")
    assert result is not None
```

### **Integration Test**

```python
async def test_full_conversion_pipeline():
    # Real MCP session
    connector = StdioConnector("npx", ["@playwright/mcp"])
    session = MCPSession(connector)
    
    async with session:
        adapter = ToolAdapter()
        tools = await adapter.create_tools(session)
        
        # Verify tools are usable
        assert len(tools) > 0
        
        # Test a real tool call
        navigate_tool = next(t for t in tools if t.name == "playwright_navigate")
        result = await navigate_tool._arun(url="https://example.com")
        assert "navigated" in result.lower()
```

## 💡 Key Takeaways

### **What Adapters Do** 🎯
- **Universal Conversion**: Any MCP server → LangChain tools
- **Type Safety**: JSON Schema → Pydantic models with validation
- **Multi-Format Support**: Tools, resources, prompts all supported
- **Error Translation**: MCP errors → LLM-friendly messages

### **Why They Matter** 💪
- **Ecosystem Compatibility**: Use any MCP server with any LangChain agent
- **Type Safety**: Catch parameter errors before tool execution
- **Developer Experience**: Clean, predictable tool interfaces
- **Error Resilience**: Graceful handling of tool failures

### **The Big Picture** 🌟
Adapters are the **"universal connector"** that makes the entire MCP ecosystem compatible with LangChain. They handle all the complex translation work so you can focus on building great AI agents!

Think of them as the **"Rosetta Stone"** for AI tools - translating between different "languages" so everything can work together seamlessly! 🗿✨