"""
AI agent implementations for MCP tool integration.

This module provides both traditional LangChain agents and enhanced LangGraph agents
with built-in streaming display and advanced memory management.
"""

from mcp_conductor.agents.agent import Agent
from mcp_conductor.agents.langgraph_agent import (
    LangGraphAgent,
    AgentConfigurationProvider,
    DefaultConfigurationProvider,
    StreamDisplayMode,
    StreamingFormatter
)

__all__ = [
    # Traditional LangChain agent
    "Agent",

    # Enhanced LangGraph agent
    "LangGraphAgent",

    # Configuration providers
    "AgentConfigurationProvider",
    "DefaultConfigurationProvider",

    # Streaming display
    "StreamDisplayMode",
    "StreamingFormatter",
]