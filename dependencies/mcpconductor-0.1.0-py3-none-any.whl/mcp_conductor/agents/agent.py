"""
Main agent integration for mcp_conductor.

This module provides the main Agent class that integrates all components
to provide a simple interface for using MCP tools with different LLMs,
following mcp_use patterns exactly.
"""

from collections.abc import AsyncGenerator
from typing import TypeVar

from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.schema import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langchain.schema.language_model import BaseLanguageModel
from langchain_core.agents import AgentAction, AgentFinish
from langchain_core.exceptions import OutputParserException
from langchain_core.tools import BaseTool
from langchain_core.utils.input import get_color_mapping
from pydantic import BaseModel

from mcp_conductor.adapters import ToolAdapter
from mcp_conductor.clients.client import MCPClient
from mcp_conductor.core.logging import logger
from mcp_conductor.observability import langfuse_handler
from mcp_conductor.prompts.system_prompt_builder import create_system_message
from mcp_conductor.prompts.templates import DEFAULT_SYSTEM_PROMPT_TEMPLATE, SERVER_MANAGER_SYSTEM_PROMPT_TEMPLATE

# Type variable for structured output
T = TypeVar("T", bound=BaseModel)


class Agent:
    """Main class for using MCP tools with various LLM providers.

    This class provides a unified interface for using MCP tools with different LLM providers
    through LangChain's agent framework, with customizable system prompts and conversation memory.
    Following mcp_use patterns exactly.
    """

    def __init__(
        self,
        llm: BaseLanguageModel,
        client: MCPClient | None = None,
        command: str = "npx",
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
        max_steps: int = 10,
        memory_enabled: bool = True,
        system_prompt: str | None = None,
        system_prompt_template: str | None = None,
        additional_instructions: str | None = None,
        disallowed_tools: list[str] | None = None,
        use_server_manager: bool = False,
        verbose: bool = False,
    ):
        """Initialize a new Agent instance.

        Args:
            llm: The LangChain LLM to use.
            client: Optional MCPClient to use. If provided, command/args/env are ignored.
            command: The command to execute for the MCP server (ignored if client provided).
            args: Optional command line arguments for the MCP server (ignored if client provided).
            env: Optional environment variables for the MCP server (ignored if client provided).
            max_steps: The maximum number of steps to take.
            memory_enabled: Whether to maintain conversation history for context.
            system_prompt: Complete system prompt to use (overrides template if provided).
            system_prompt_template: Template for system prompt with {tool_descriptions} placeholder.
            additional_instructions: Extra instructions to append to the system prompt.
            disallowed_tools: List of tool names that should not be available to the agent.
            use_server_manager: Whether to use server manager mode.
            verbose: Whether to enable verbose logging during execution.
        """
        self.llm = llm
        self.max_steps = max_steps
        self.memory_enabled = memory_enabled
        self.system_prompt = system_prompt
        self.system_prompt_template_override = system_prompt_template
        self.additional_instructions = additional_instructions
        self.disallowed_tools = disallowed_tools or []
        self.use_server_manager = use_server_manager
        self.verbose = verbose

        # Add Langfuse handler if available
        if langfuse_handler:
            self.llm = llm.with_config({"callbacks": [langfuse_handler]})

        # Create or use provided MCPClient
        if client is not None:
            # Use provided client
            self.client = client
        else:
            # Create simple client from command/args/env
            self.command = command
            self.args = args or []
            self.env = env

            server_config = {
                "mcpServers": {
                    "default": {
                        "command": self.command,
                        "args": self.args,
                        "env": self.env or {}
                    }
                }
            }
            self.client = MCPClient.from_dict(server_config)

        # Create the adapter for tool conversion
        self.adapter = ToolAdapter(disallowed_tools=self.disallowed_tools)

        # Internal state
        self._initialized = False
        self._conversation_history: list[BaseMessage] = []
        self._tools: list[BaseTool] = []
        self._agent_executor: AgentExecutor | None = None
        self._system_message: SystemMessage | None = None

    async def initialize(self) -> None:
        """Initialize the agent and connect to MCP server."""
        logger.info("🚀 Initializing agent and connecting to MCP server...")

        # Create sessions for all configured servers
        await self.client.create_all_sessions()

        # Create LangChain tools from the client using the adapter
        self._tools = await self.adapter.create_tools_from_client(self.client)
        logger.info(f"🛠️ Created {len(self._tools)} LangChain tools from MCP server")

        # Create the system message based on available tools
        await self._create_system_message_from_tools(self._tools)

        # Create the agent executor
        self._agent_executor = self._create_agent()
        self._initialized = True

        logger.info("✨ Agent initialization complete")

    async def _create_system_message_from_tools(self, tools: list[BaseTool]) -> None:
        """Create the system message based on provided tools using the builder."""
        # Use the override if provided, otherwise use the imported default
        default_template = self.system_prompt_template_override or DEFAULT_SYSTEM_PROMPT_TEMPLATE

        # Delegate creation to the imported function
        self._system_message = create_system_message(
            tools=tools,
            system_prompt_template=default_template,
            server_manager_template=SERVER_MANAGER_SYSTEM_PROMPT_TEMPLATE,
            use_server_manager=self.use_server_manager,
            disallowed_tools=self.disallowed_tools,
            user_provided_prompt=self.system_prompt,
            additional_instructions=self.additional_instructions,
        )

        # Update conversation history if memory is enabled
        if self.memory_enabled:
            history_without_system = [msg for msg in self._conversation_history if not isinstance(msg, SystemMessage)]
            self._conversation_history = [self._system_message] + history_without_system

    def _create_agent(self) -> AgentExecutor:
        """Create the LangChain agent with the configured system message."""
        logger.debug(f"Creating new agent with {len(self._tools)} tools")

        system_content = "You are a helpful assistant"
        if self._system_message:
            system_content = self._system_message.content

        prompt = ChatPromptTemplate.from_messages([
            ("system", system_content),
            MessagesPlaceholder(variable_name="chat_history"),
            ("human", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad"),
        ])

        tool_names = [tool.name for tool in self._tools]
        logger.info(f"🧠 Agent ready with tools: {', '.join(tool_names)}")

        # Use the standard create_tool_calling_agent
        agent = create_tool_calling_agent(llm=self.llm, tools=self._tools, prompt=prompt)

        callbacks = []
        try:
            from .observability import langfuse_handler
            if langfuse_handler:
                callbacks = [langfuse_handler]
                logger.info(f"✅ Added Langfuse callback to AgentExecutor")
            else:
                logger.debug("No Langfuse handler available")
        except Exception as e:
            logger.debug(f"No Langfuse observability: {e}")

        executor = AgentExecutor(
            agent=agent,
            tools=self._tools,
            max_iterations=self.max_steps,
            verbose=self.verbose,
            callbacks=callbacks
        )

        logger.debug(f"Created agent executor with max_iterations={self.max_steps}, callbacks={len(callbacks)}")
        return executor

    def add_to_history(self, message: BaseMessage) -> None:
        """Add a message to the conversation history."""
        if self.memory_enabled:
            self._conversation_history.append(message)

    def clear_conversation_history(self) -> None:
        """Clear the conversation history."""
        self._conversation_history = []
        if self._system_message and self.memory_enabled:
            self._conversation_history = [self._system_message]

    async def stream(
            self,
            query: str,
            max_steps: int | None = None,
    ) -> AsyncGenerator[tuple[AgentAction, str] | str, None]:
        """Run the agent and yield intermediate steps as an async generator."""
        # Initialize if needed
        if not self._initialized:
            await self.initialize()

        if not self._agent_executor:
            raise RuntimeError("Agent failed to initialize")

        steps = max_steps or self.max_steps
        self._agent_executor.max_iterations = steps

        display_query = query[:50].replace("\n", " ") + "..." if len(query) > 50 else query.replace("\n", " ")
        logger.info(f"💬 Received query: '{display_query}'")

        # Add the user query to conversation history
        if self.memory_enabled:
            self.add_to_history(HumanMessage(content=query))

        # Convert conversation history to LangChain format
        langchain_history = []
        for msg in self._conversation_history:
            if isinstance(msg, HumanMessage):
                langchain_history.append(msg)
            elif isinstance(msg, AIMessage):
                langchain_history.append(msg)

        intermediate_steps: list[tuple[AgentAction, str]] = []
        inputs = {"input": query, "chat_history": langchain_history}

        # Construct mapping for agent execution
        name_to_tool_map = {tool.name: tool for tool in self._tools}
        color_mapping = get_color_mapping([tool.name for tool in self._tools], excluded_colors=["green", "red"])

        logger.info(f"🏃 Starting agent execution with max_steps={steps}")

        result = ""
        reached_max_steps = False  # Track if we actually hit the limit
        step_num = 0

        for step_num in range(steps):
            logger.info(f"👣 Step {step_num + 1}/{steps}")

            try:
                # Execute next step using mcp_use pattern
                next_step_output = await self._agent_executor._atake_next_step(
                    name_to_tool_map=name_to_tool_map,
                    color_mapping=color_mapping,
                    inputs=inputs,
                    intermediate_steps=intermediate_steps,
                    run_manager=None,
                )

                # Process the output
                if isinstance(next_step_output, AgentFinish):
                    logger.info(f"✅ Agent finished at step {step_num + 1}")
                    result = next_step_output.return_values.get("output", "No output generated")
                    break

                # If it's actions/steps, add to intermediate steps and yield them
                intermediate_steps.extend(next_step_output)

                # Yield each step and track tool usage
                for agent_step in next_step_output:
                    yield agent_step
                    action, observation = agent_step
                    tool_name = action.tool
                    tool_input_str = str(action.tool_input)
                    if len(tool_input_str) > 100:
                        tool_input_str = tool_input_str[:97] + "..."
                    logger.info(f"🔧 Tool call: {tool_name} with input: {tool_input_str}")

                    observation_str = str(observation)
                    if len(observation_str) > 100:
                        observation_str = observation_str[:97] + "..."
                    observation_str = observation_str.replace("\n", " ")
                    logger.info(f"📄 Tool result: {observation_str}")

                # Check for return_direct on the last action taken
                if len(next_step_output) > 0:
                    last_step: tuple[AgentAction, str] = next_step_output[-1]
                    tool_return = self._agent_executor._get_tool_return(last_step)
                    if tool_return is not None:
                        logger.info(f"🎯 Tool returned directly at step {step_num + 1}")
                        result = tool_return.return_values.get("output", "No output generated")
                        break

            except OutputParserException as e:
                logger.error(f"❌ Output parsing error during step {step_num + 1}: {e}")
                result = f"Agent stopped due to a parsing error: {str(e)}"
                break
            except Exception as e:
                logger.error(f"❌ Error during agent execution step {step_num + 1}: {e}")
                result = f"Agent stopped due to an error: {str(e)}"
                break
        else:
            # This else clause executes only if the loop completed without breaking
            reached_max_steps = True

        # Handle case where max steps reached vs early completion
        if not result:
            if reached_max_steps:
                logger.warning(f"⚠️ Agent stopped after reaching max iterations ({steps})")
                result = f"Agent stopped after reaching the maximum number of steps ({steps})."
            else:
                logger.info(f"✅ Agent completed execution without generating output")
                result = f"Agent completed execution in {step_num + 1} steps but did not generate a final result."
        elif reached_max_steps:
            logger.warning(f"⚠️ Agent stopped after reaching max iterations ({steps})")
            result = f"Agent stopped after reaching the maximum number of steps ({steps})."

        # Add AI response to conversation history
        if self.memory_enabled:
            self.add_to_history(AIMessage(content=result))

        logger.info("🎉 Agent execution complete")

        # Yield the final result
        yield result

    async def run(
        self,
        query: str,
        max_steps: int | None = None,
        output_schema: type[T] | None = None,
    ) -> str | T:
        """Run a query using the MCP tools and return the final result."""
        if output_schema:
            return await self._run_with_structured_output(query, max_steps, output_schema)

        # Regular execution
        final_result = ""
        async for item in self.stream(query, max_steps):
            if isinstance(item, str):
                final_result = item
                break

        return final_result

    async def _run_with_structured_output(
        self,
        query: str,
        max_steps: int | None,
        output_schema: type[T],
    ) -> T:
        """Run query and return structured output."""
        # Get schema description
        schema_fields = []
        try:
            for field_name, field_info in output_schema.model_fields.items():
                description = getattr(field_info, "description", "") or field_name
                required = not hasattr(field_info, "default") or field_info.default is None
                schema_fields.append(f"- {field_name}: {description} {'(required)' if required else '(optional)'}")
            schema_description = "\n".join(schema_fields)
        except Exception:
            schema_description = f"Schema: {output_schema.__name__}"

        # Enhance query with schema awareness
        enhanced_query = f"""
        {query}

        IMPORTANT: Your response must include sufficient information to populate the following structured output:

        {schema_description}

        Make sure you gather ALL the required information during your task execution.
        """

        # Run the enhanced query
        raw_result = await self.run(enhanced_query, max_steps)

        # Convert to structured output
        structured_llm = self.llm.with_structured_output(output_schema)

        format_prompt = f"""
        Based on the following task execution result, create a structured summary:

        {raw_result}

        Format this information according to the required schema. If any required information is missing, indicate this clearly.
        """

        structured_result = await structured_llm.ainvoke(format_prompt)
        return structured_result

    async def close(self) -> None:
        """Close the agent and clean up resources."""
        logger.info("🔌 Closing agent and cleaning up resources...")

        try:
            if self.client:
                await self.client.close_all_sessions()

            self._agent_executor = None
            self._tools = []
            self._initialized = False

            logger.info("👋 Agent closed successfully")

        except Exception as e:
            logger.error(f"❌ Error during agent closure: {e}")
            # Clean up references even if there was an error
            self._agent_executor = None
            self._tools = []
            self._initialized = False

    async def __aenter__(self):
        """Enter async context manager."""
        await self.initialize()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Exit async context manager."""
        await self.close()