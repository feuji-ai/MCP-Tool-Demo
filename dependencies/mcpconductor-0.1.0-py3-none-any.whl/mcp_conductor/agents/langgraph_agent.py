"""
Enhanced LangGraph Agent with Built-in Rich Streaming Display + CONTROLLABLE LANGFUSE

This enhanced version provides beautiful console output out-of-the-box
without requiring users to write custom streaming handlers.
"""

import uuid
import time
from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator
from typing import Any, TypeVar, Optional, Dict, List
from enum import Enum

from langchain.schema.language_model import BaseLanguageModel
from langchain_core.tools import BaseTool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.prebuilt import create_react_agent
from pydantic import BaseModel

from mcp_conductor.adapters import ToolAdapter
from mcp_conductor.clients.client import MCPClient
from mcp_conductor.core.logging import logger
from mcp_conductor.prompts.system_prompt_builder import create_system_message
from mcp_conductor.prompts.templates import DEFAULT_SYSTEM_PROMPT_TEMPLATE, SERVER_MANAGER_SYSTEM_PROMPT_TEMPLATE

# Type variable for structured output
T = TypeVar("T", bound=BaseModel)


class StreamDisplayMode(Enum):
    """Streaming display modes for console output."""
    DISABLED = "disabled"           # No console output
    MINIMAL = "minimal"             # Basic progress indicators
    STANDARD = "standard"           # Tool calls and results
    DETAILED = "detailed"           # Full details with AI reasoning
    RICH = "rich"                   # Maximum detail with statistics
    STEALTH = "stealth"             # Maximum detail BUT hides input prompt!


class AgentConfigurationProvider(ABC):
    """Abstract base class for providing flexible agent configuration."""

    @abstractmethod
    def get_trace_name(self, query: str, thread_id: str) -> Optional[str]:
        """Generate custom trace name for this execution."""
        pass

    @abstractmethod
    def get_session_id(self, thread_id: str) -> Optional[str]:
        """Provide custom session ID for trace grouping."""
        pass

    @abstractmethod
    def get_user_id(self) -> Optional[str]:
        """Provide user ID for user tracking."""
        pass

    @abstractmethod
    def get_tags(self, query: str) -> List[str]:
        """Generate tags for trace filtering and organization."""
        pass

    @abstractmethod
    def get_metadata(self, query: str, thread_id: str) -> Dict[str, Any]:
        """Generate custom metadata for detailed trace context."""
        pass

    def get_additional_config(self, query: str, thread_id: str) -> Dict[str, Any]:
        """Provide additional configuration for agent execution."""
        return {}


class DefaultConfigurationProvider(AgentConfigurationProvider):
    """Default configuration provider that maintains backward compatibility."""

    def get_trace_name(self, query: str, thread_id: str) -> Optional[str]:
        return None

    def get_session_id(self, thread_id: str) -> Optional[str]:
        return thread_id

    def get_user_id(self) -> Optional[str]:
        return None

    def get_tags(self, query: str) -> List[str]:
        return ["mcp-conductor"]

    def get_metadata(self, query: str, thread_id: str) -> Dict[str, Any]:
        return {
            "thread_id": thread_id,
            "query_length": len(query)
        }


class StreamingFormatter:
    """Built-in formatter for beautiful streaming console output."""

    def __init__(self, mode: StreamDisplayMode = StreamDisplayMode.STANDARD):
        self.mode = mode
        self.step_count = 0
        self.tool_call_count = 0
        self.start_time = time.time()
        # Buffer for pending tool calls
        self.pending_tool_call = None

    def format_header(self, query: str, thread_id: str, stage_name: str = None) -> str:
        """Format execution header."""
        if self.mode == StreamDisplayMode.DISABLED:
            return ""

        lines = []

        if self.mode == StreamDisplayMode.STEALTH:
            stage_text = f" - {stage_name.upper()}" if stage_name else ""
            lines.append(f"\n🥷 MCP CONDUCTOR STEALTH EXECUTION{stage_text}")
            lines.append("=" * 80)
            lines.append(f"🧵 Thread ID: {thread_id}")
            lines.append(f"🎯 Status: Executing classified operation...")
            lines.append(f"🔒 Query: [HIDDEN FOR PRIVACY]")
            lines.append("\n🎬 LIVE EXECUTION STEPS:")
            lines.append("-" * 50)

        elif self.mode in [StreamDisplayMode.DETAILED, StreamDisplayMode.RICH]:
            stage_text = f" - {stage_name.upper()}" if stage_name else ""
            lines.append(f"\n🔥 MCP CONDUCTOR EXECUTION{stage_text}")
            lines.append("=" * 80)
            lines.append(f"📝 Query: {query}")
            lines.append(f"🧵 Thread ID: {thread_id}")
            lines.append("\n🎬 LIVE EXECUTION STEPS:")
            lines.append("-" * 50)

        elif self.mode == StreamDisplayMode.STANDARD:
            lines.append(f"\n🚀 Executing: {query[:60]}{'...' if len(query) > 60 else ''}")
            lines.append("-" * 50)

        elif self.mode == StreamDisplayMode.MINIMAL:
            lines.append(f"🚀 Starting execution...")

        return "\n".join(lines)

    def format_tool_call(self, tool_name: str, tool_input: Any) -> str:
        """Buffer tool call - don't display until we get the result."""
        if self.mode == StreamDisplayMode.DISABLED:
            return ""

        # Format tool input
        if isinstance(tool_input, dict):
            input_preview = ", ".join([f"{k}={v}" for k, v in list(tool_input.items())[:3]])
            if len(tool_input) > 3:
                input_preview += "..."
        else:
            input_preview = str(tool_input)[:100]

        # Store the tool call info for when result comes
        self.pending_tool_call = {
            "tool_name": tool_name,
            "input_preview": input_preview
        }

        # Don't display anything yet - wait for the result
        return ""

    def format_tool_result(self, content) -> str:
        """Format tool call + result as one combined step."""
        if self.mode == StreamDisplayMode.DISABLED:
            return ""

        if not self.pending_tool_call:
            return self._format_standalone_result(content)

        self.step_count += 1
        self.tool_call_count += 1

        tool_name = self.pending_tool_call["tool_name"]
        input_preview = self.pending_tool_call["input_preview"]

        # Convert content to string first to handle both string and list content
        if isinstance(content, list):
            text_content = ""
            for item in content:
                if isinstance(item, dict) and "text" in item:
                    text_content += item["text"]
                elif isinstance(item, str):
                    text_content += item
            content_str = text_content if text_content else str(content)
        else:
            content_str = str(content)

        content_preview = content_str[:150] + "..." if len(content_str) > 150 else content_str
        content_preview = content_preview.replace('\n', ' ')

        self.pending_tool_call = None

        if self.mode == StreamDisplayMode.STEALTH:
            return f"\n🥷 Step {self.step_count} - STEALTH TOOL EXECUTION #{self.tool_call_count}\n   🛠️  Tool: {tool_name}\n   📥 Input: {input_preview}\n   ✅ Output: {content_preview}\n"
        elif self.mode == StreamDisplayMode.RICH:
            return f"\n🔧 Step {self.step_count} - TOOL EXECUTION #{self.tool_call_count}\n   🛠️  Tool: {tool_name}\n   📥 Input: {input_preview}\n   ✅ Output: {content_preview}\n"
        elif self.mode == StreamDisplayMode.DETAILED:
            return f"🔧 {tool_name}({input_preview}) → {content_preview}"
        elif self.mode == StreamDisplayMode.STANDARD:
            return f"🔧 {tool_name} ✅"
        elif self.mode == StreamDisplayMode.MINIMAL:
            return "🔧✅"

        return ""

    def _format_standalone_result(self, content) -> str:
        """Format standalone result (fallback when no pending tool call)."""
        self.step_count += 1

        # Convert content to string first to handle both string and list content
        if isinstance(content, list):
            text_content = ""
            for item in content:
                if isinstance(item, dict) and "text" in item:
                    text_content += item["text"]
                elif isinstance(item, str):
                    text_content += item
            content_str = text_content if text_content else str(content)
        else:
            content_str = str(content)

        content_preview = content_str[:150] + "..." if len(content_str) > 150 else content_str
        content_preview = content_preview.replace('\n', ' ')

        if self.mode == StreamDisplayMode.STEALTH:
            return f"🥷 Step {self.step_count} - STEALTH RESULT\n   ✅ Output: {content_preview}\n"
        elif self.mode == StreamDisplayMode.RICH:
            return f"📄 Step {self.step_count} - RESULT\n   ✅ Output: {content_preview}\n"
        elif self.mode == StreamDisplayMode.DETAILED:
            return f"📄 Result: {content_preview}"
        elif self.mode == StreamDisplayMode.STANDARD:
            return f"📄 ✅"
        elif self.mode == StreamDisplayMode.MINIMAL:
            return "✅"

        return ""

    def format_ai_message(self, content) -> str:
        """Format AI reasoning output."""
        if self.mode not in [StreamDisplayMode.DETAILED, StreamDisplayMode.RICH, StreamDisplayMode.STEALTH]:
            return ""

        if not content:
            return ""

        # Convert content to string first to handle both string and list content
        if isinstance(content, list):
            text_content = ""
            for item in content:
                if isinstance(item, dict) and "text" in item:
                    text_content += item["text"]
                elif isinstance(item, str):
                    text_content += item
            content_str = text_content if text_content else str(content)
        else:
            content_str = str(content)

        content_preview = content_str[:100] + "..." if len(content_str) > 100 else content_str
        content_preview = content_preview.replace('\n', ' ')

        if self.mode == StreamDisplayMode.STEALTH:
            return f"🤖 STEALTH AI REASONING\n   🥷 Thinking: {content_preview}\n"
        elif self.mode == StreamDisplayMode.RICH:
            return f"🤖 AI REASONING\n   💭 Thinking: {content_preview}\n"
        else:
            return f"🤖 Thinking: {content_preview}"

    def format_final_result(self, result: str) -> str:
        """Format final result output."""
        if self.mode == StreamDisplayMode.DISABLED:
            return ""

        lines = []
        execution_time = time.time() - self.start_time

        if self.mode in [StreamDisplayMode.DETAILED, StreamDisplayMode.RICH, StreamDisplayMode.STEALTH]:
            if self.mode == StreamDisplayMode.STEALTH:
                lines.append("\n🥷 STEALTH MISSION COMPLETE")
                lines.append("=" * 50)
            else:
                lines.append("\n🎯 FINAL RESULT")
                lines.append("=" * 50)

            if len(result) > 500:
                lines.append(f"📋 Result Preview: {result[:500]}...")
                lines.append(f"📄 Full result length: {len(result)} characters")
            else:
                lines.append(f"📋 Complete Result: {result}")

            if self.mode == StreamDisplayMode.STEALTH:
                lines.append(f"\n🥷 STEALTH EXECUTION STATISTICS")
            else:
                lines.append(f"\n📊 EXECUTION STATISTICS")
            lines.append("-" * 50)
            lines.append(f"⏱️  Total Time: {execution_time:.2f} seconds")
            lines.append(f"🔧 Tool Executions: {self.tool_call_count}")
            lines.append(f"📝 Total Steps: {self.step_count}")

            if self.mode == StreamDisplayMode.STEALTH:
                lines.append(f"🥷 Status: {'Mission Success' if result and not result.startswith('Error:') else 'Mission Failed'}")
            else:
                lines.append(f"✅ Status: {'Success' if result and not result.startswith('Error:') else 'Failed'}")

        elif self.mode == StreamDisplayMode.STANDARD:
            lines.append(f"\n✅ Completed in {execution_time:.1f}s with {self.tool_call_count} tool executions")
            lines.append(f"📋 Result: {result[:200]}{'...' if len(result) > 200 else ''}")

        elif self.mode == StreamDisplayMode.MINIMAL:
            lines.append(f"✅ Done ({execution_time:.1f}s)")

        return "\n".join(lines)

    def format_error(self, error: str) -> str:
        """Format error output."""
        if self.mode == StreamDisplayMode.DISABLED:
            return ""

        execution_time = time.time() - self.start_time

        if self.mode in [StreamDisplayMode.DETAILED, StreamDisplayMode.RICH, StreamDisplayMode.STEALTH]:
            if self.mode == StreamDisplayMode.STEALTH:
                return f"\n🥷 STEALTH MISSION FAILED: {error}\n⏱️  Mission failed after {execution_time:.2f} seconds with {self.tool_call_count} tool executions"
            else:
                return f"\n❌ ERROR: {error}\n⏱️  Failed after {execution_time:.2f} seconds with {self.tool_call_count} tool executions"
        else:
            return f"❌ Error: {error}"


class LangGraphAgent:
    """
    LangGraph-powered agent with built-in rich streaming display and controllable Langfuse tracing.

    This agent provides beautiful console output out-of-the-box without requiring
    users to write custom streaming handlers, and explicit control over Langfuse observability.
    """

    def __init__(
        self,
        llm: BaseLanguageModel,
        client: MCPClient | None = None,
        command: str = "npx",
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
        max_steps: int = 10,
        memory_enabled: bool = True,
        system_prompt: str | None = None,
        system_prompt_template: str | None = None,
        additional_instructions: str | None = None,
        disallowed_tools: list[str] | None = None,
        use_server_manager: bool = False,
        verbose: bool = False,
        thread_id: str | None = None,
        config_provider: AgentConfigurationProvider | None = None,

        # Streaming display options
        stream_display_mode: StreamDisplayMode = StreamDisplayMode.STANDARD,
        auto_print_streaming: bool = True,
        custom_formatter: StreamingFormatter | None = None,

        # Langfuse observability control
        enable_langfuse: bool = False,
    ):
        """
        Initialize a new LangGraph Agent instance with controllable Langfuse tracing.

        Args:
            llm: The LangChain LLM to use.
            client: Optional MCPClient to use. If provided, command/args/env are ignored.
            command: The command to execute for the MCP server (ignored if client provided).
            args: Optional command line arguments for the MCP server.
            env: Optional environment variables for the MCP server.
            max_steps: The maximum number of steps to take.
            memory_enabled: Whether to maintain conversation history for context.
            system_prompt: Complete system prompt to use (overrides template if provided).
            system_prompt_template: Template for system prompt with {tool_descriptions} placeholder.
            additional_instructions: Extra instructions to append to the system prompt.
            disallowed_tools: List of tool names that should not be available to the agent.
            use_server_manager: Whether to use server manager mode.
            verbose: Whether to enable verbose logging during execution.
            thread_id: Optional thread ID for conversation persistence.
            config_provider: Optional configuration provider for custom observability.
            stream_display_mode: Display mode for streaming output.
            auto_print_streaming: Whether to automatically print streaming output to console.
            custom_formatter: Optional custom formatter for streaming display.
            enable_langfuse: Whether to enable Langfuse tracing (default: False).
                           All Langfuse configuration comes from config_provider.
        """
        self.llm = llm
        self.max_steps = max_steps
        self.memory_enabled = memory_enabled
        self.system_prompt = system_prompt
        self.system_prompt_template_override = system_prompt_template
        self.additional_instructions = additional_instructions
        self.disallowed_tools = disallowed_tools or []
        self.use_server_manager = use_server_manager
        self.verbose = verbose

        # LangGraph-specific initialization
        self.thread_id = thread_id or str(uuid.uuid4())
        self.checkpointer = InMemorySaver() if memory_enabled else None
        self.config_provider = config_provider or DefaultConfigurationProvider()

        # Built-in streaming display
        self.stream_display_mode = stream_display_mode
        self.auto_print_streaming = auto_print_streaming
        self.custom_formatter = custom_formatter

        # Langfuse control
        self.enable_langfuse = enable_langfuse

        # Only add Langfuse if explicitly enabled
        if self.enable_langfuse:
            try:
                from mcp_conductor.observability import langfuse_handler
                if langfuse_handler:
                    self.llm = llm.with_config({"callbacks": [langfuse_handler]})
                    logger.info("✅ Langfuse tracing enabled for agent")
                else:
                    logger.warning("⚠️ Langfuse requested but not available (check environment variables)")
            except ImportError:
                logger.warning("⚠️ Langfuse requested but package not installed")
        else:
            logger.debug("📊 Langfuse tracing disabled for agent")

        # Create or use provided MCPClient
        if client is not None:
            self.client = client
        else:
            self.command = command
            self.args = args or []
            self.env = env

            server_config = {
                "mcpServers": {
                    "default": {
                        "command": self.command,
                        "args": self.args,
                        "env": self.env or {}
                    }
                }
            }
            self.client = MCPClient.from_dict(server_config)

        # Create the adapter for tool conversion
        self.adapter = ToolAdapter(disallowed_tools=self.disallowed_tools)

        # Internal state
        self._initialized = False
        self._tools: list[BaseTool] = []
        self._langgraph_agent = None
        self._system_message_content: str = ""

    async def initialize(self) -> None:
        """Initialize the agent and connect to MCP server."""
        logger.info("🚀 Initializing LangGraph agent and connecting to MCP server...")

        await self.client.create_all_sessions()
        self._tools = await self.adapter.create_tools_from_client(self.client)
        logger.info(f"🛠️ Created {len(self._tools)} LangChain tools from MCP server")

        await self._create_system_message_content_from_tools(self._tools)
        self._langgraph_agent = self._create_langgraph_agent()
        self._initialized = True

        logger.info("✨ LangGraph agent initialization complete")

    async def _create_system_message_content_from_tools(self, tools: list[BaseTool]) -> None:
        """Create the system message content based on provided tools using the builder."""
        default_template = self.system_prompt_template_override or DEFAULT_SYSTEM_PROMPT_TEMPLATE

        system_message = create_system_message(
            tools=tools,
            system_prompt_template=default_template,
            server_manager_template=SERVER_MANAGER_SYSTEM_PROMPT_TEMPLATE,
            use_server_manager=self.use_server_manager,
            disallowed_tools=self.disallowed_tools,
            user_provided_prompt=self.system_prompt,
            additional_instructions=self.additional_instructions,
        )

        self._system_message_content = system_message.content

    def _create_langgraph_agent(self):
        """Create the LangGraph agent using create_react_agent."""
        logger.debug(f"Creating LangGraph agent with {len(self._tools)} tools")

        # Only add Langfuse callbacks if explicitly enabled
        callbacks = []
        if self.enable_langfuse:
            try:
                from mcp_conductor.observability import langfuse_handler
                if langfuse_handler:
                    callbacks = [langfuse_handler]
                    logger.info("✅ Added Langfuse callback to LangGraph agent")
            except ImportError:
                logger.debug("Langfuse not available for LangGraph agent")

        llm_with_callbacks = self.llm
        if callbacks:
            llm_with_callbacks = self.llm.with_config({"callbacks": callbacks})

        agent = create_react_agent(
            model=llm_with_callbacks,
            tools=self._tools,
            prompt=self._system_message_content,
            checkpointer=self.checkpointer,
        )

        tool_names = [tool.name for tool in self._tools]
        logger.info(f"🧠 LangGraph agent ready with tools: {', '.join(tool_names)}")

        return agent

    def _get_config(self, query: str = "") -> dict[str, Any]:
        """Get the configuration for LangGraph agent invocation with controllable observability."""
        config = {
            "configurable": {"thread_id": self.thread_id},
            "recursion_limit": self.max_steps
        }

        # Only add Langfuse if explicitly enabled
        if self.enable_langfuse:
            try:
                from mcp_conductor.observability import langfuse_handler
                if langfuse_handler:
                    config["callbacks"] = [langfuse_handler]
                    langfuse_metadata = self._build_langfuse_metadata(query)
                    if langfuse_metadata:
                        # Extract trace configuration
                        if "langfuse_trace_name" in langfuse_metadata:
                            config["run_name"] = langfuse_metadata["langfuse_trace_name"]
                            config["langfuse_trace_name"] = langfuse_metadata["langfuse_trace_name"]

                        if "langfuse_user_id" in langfuse_metadata:
                            config["langfuse_user_id"] = langfuse_metadata["langfuse_user_id"]

                        if "langfuse_session_id" in langfuse_metadata:
                            config["langfuse_session_id"] = langfuse_metadata["langfuse_session_id"]

                        if "langfuse_tags" in langfuse_metadata:
                            config["langfuse_tags"] = langfuse_metadata["langfuse_tags"]

                        config["metadata"] = langfuse_metadata
            except Exception as e:
                logger.debug(f"Langfuse callback error: {e}")

        # Additional configuration from config_provider
        try:
            additional_config = self.config_provider.get_additional_config(query, self.thread_id)
            config.update(additional_config)
        except Exception as e:
            logger.debug(f"Error getting additional config: {e}")

        return config

    def _build_langfuse_metadata(self, query: str) -> Dict[str, Any]:
        """Build Langfuse metadata using the configuration provider."""
        # Only build metadata if Langfuse is enabled
        if not self.enable_langfuse:
            return {}

        try:
            metadata = {}

            # All configuration comes from config_provider (unchanged)
            trace_name = self.config_provider.get_trace_name(query, self.thread_id)
            if trace_name:
                metadata["langfuse_trace_name"] = trace_name

            session_id = self.config_provider.get_session_id(self.thread_id)
            if session_id:
                metadata["langfuse_session_id"] = session_id

            user_id = self.config_provider.get_user_id()
            if user_id:
                metadata["langfuse_user_id"] = user_id

            tags = self.config_provider.get_tags(query)
            if tags:
                metadata["langfuse_tags"] = tags

            custom_metadata = self.config_provider.get_metadata(query, self.thread_id)
            if custom_metadata:
                metadata.update(custom_metadata)

            return metadata

        except Exception as e:
            logger.warning(f"Error building Langfuse metadata: {e}")
            return {}

    async def stream(
            self,
            query: str,
            max_steps: int | None = None,
            stage_name: str | None = None,
    ) -> AsyncGenerator[dict[str, Any] | str, None]:
        """
        Run the agent and yield intermediate steps with BUILT-IN beautiful console display.

        This method now provides rich console output out-of-the-box without requiring
        users to write custom streaming handlers.

        Use StreamDisplayMode.STEALTH for maximum detail with hidden prompts!

        Args:
            query: The query to execute
            max_steps: Maximum steps to take
            stage_name: Optional stage name for display

        Yields:
            Streaming execution updates and final result
        """
        # Initialize if needed
        if not self._initialized:
            await self.initialize()

        if not self._langgraph_agent:
            raise RuntimeError("LangGraph agent failed to initialize")

        display_query = query[:50].replace("\n", " ") + "..." if len(query) > 50 else query.replace("\n", " ")
        logger.info(f"💬 Received query: '{display_query}'")
        logger.info(f"🏃 Starting LangGraph agent execution with thread_id={self.thread_id}")

        # Initialize streaming formatter
        formatter = self.custom_formatter or StreamingFormatter(self.stream_display_mode)

        # Print header if auto-print is enabled
        if self.auto_print_streaming:
            header = formatter.format_header(query, self.thread_id, stage_name)
            if header:
                print(header)

        # Prepare input in LangGraph format
        messages = [{"role": "user", "content": query}]
        config = self._get_config(query)

        final_message_content = ""

        try:
            async for chunk in self._langgraph_agent.astream(
                    {"messages": messages},
                    config=config,
                    stream_mode="values"
            ):
                if "messages" in chunk:
                    latest_message = chunk["messages"][-1]

                    if hasattr(latest_message, 'tool_calls') and latest_message.tool_calls:
                        for tool_call in latest_message.tool_calls:
                            tool_call_data = {
                                "type": "tool_call",
                                "tool_name": tool_call.get("name", "unknown"),
                                "tool_input": tool_call.get("args", {}),
                                "message": f"🔧 Calling tool: {tool_call.get('name', 'unknown')}"
                            }

                            # Auto-print if enabled
                            if self.auto_print_streaming:
                                output = formatter.format_tool_call(
                                    tool_call_data["tool_name"],
                                    tool_call_data["tool_input"]
                                )
                                if output:
                                    print(output, end="")

                            yield tool_call_data

                    elif hasattr(latest_message, 'type') and latest_message.type == "tool":
                        tool_result_data = {
                            "type": "tool_result",
                            "content": latest_message.content[:200] + "..." if len(
                                str(latest_message.content)) > 200 else latest_message.content,
                            "message": "📄 Tool result received"
                        }

                        # Auto-print if enabled
                        if self.auto_print_streaming:
                            output = formatter.format_tool_result(str(latest_message.content))
                            if output:
                                print(output, end="")

                        yield tool_result_data

                    elif hasattr(latest_message, 'type') and latest_message.type == "ai":
                        if hasattr(latest_message, 'content') and latest_message.content:
                            final_message_content = latest_message.content

                        ai_message_data = {
                            "type": "ai_message",
                            "content": latest_message.content,
                            "message": "🤖 AI response"
                        }

                        # Auto-print if enabled
                        if self.auto_print_streaming:
                            output = formatter.format_ai_message(latest_message.content)
                            if output:
                                print(output)

                        yield ai_message_data

            # Print final result if auto-print is enabled
            if self.auto_print_streaming:
                final_output = formatter.format_final_result(
                    final_message_content or "Agent completed execution but produced no output."
                )
                if final_output:
                    print(final_output)

            # Yield final result
            final_result = final_message_content or "Agent completed execution but produced no output."
            yield final_result

            logger.info("🎉 LangGraph agent execution complete")

        except Exception as e:
            error_msg = f"Agent stopped due to an error: {str(e)}"
            logger.error(f"❌ Error during LangGraph agent execution: {e}")

            # Auto-print error if enabled
            if self.auto_print_streaming:
                error_output = formatter.format_error(str(e))
                if error_output:
                    print(error_output)

            yield error_msg

    async def run(
        self,
        query: str,
        max_steps: int | None = None,
        output_schema: type[T] | None = None,
        stage_name: str | None = None,
    ) -> str | T:
        """
        Run a query using the MCP tools and return the final result.

        Args:
            query: The query to execute
            max_steps: Maximum steps to take
            output_schema: Optional Pydantic schema for structured output
            stage_name: Optional stage name for display

        Returns:
            Final result string or structured output
        """
        if output_schema:
            return await self._run_with_structured_output(query, max_steps, output_schema)

        # Regular execution - collect final result from stream
        final_result = ""
        async for item in self.stream(query, max_steps, stage_name):
            if isinstance(item, str):
                final_result = item
            elif isinstance(item, dict) and item.get("type") == "ai_message":
                final_result = item.get("content", "")

        return final_result or "No response generated"

    async def _run_with_structured_output(
        self,
        query: str,
        max_steps: int | None,
        output_schema: type[T],
    ) -> T:
        """Run query and return structured output."""
        schema_fields = []
        try:
            for field_name, field_info in output_schema.model_fields.items():
                description = getattr(field_info, "description", "") or field_name
                required = not hasattr(field_info, "default") or field_info.default is None
                schema_fields.append(f"- {field_name}: {description} {'(required)' if required else '(optional)'}")
            schema_description = "\n".join(schema_fields)
        except Exception:
            schema_description = f"Schema: {output_schema.__name__}"

        enhanced_query = f"""
        {query}

        IMPORTANT: Your response must include sufficient information to populate the following structured output:

        {schema_description}

        Make sure you gather ALL the required information during your task execution.
        """

        raw_result = await self.run(enhanced_query, max_steps)
        structured_llm = self.llm.with_structured_output(output_schema)

        format_prompt = f"""
        Based on the following task execution result, create a structured summary:

        {raw_result}

        Format this information according to the required schema. If any required information is missing, indicate this clearly.
        """

        structured_result = await structured_llm.ainvoke(format_prompt)
        return structured_result

    def enable_tracing(self) -> None:
        """Enable Langfuse tracing."""
        self.enable_langfuse = True
        logger.info("✅ Langfuse tracing enabled")

    def disable_tracing(self) -> None:
        """Disable Langfuse tracing."""
        self.enable_langfuse = False
        logger.info("📊 Langfuse tracing disabled")

    def set_stream_display_mode(self, mode: StreamDisplayMode) -> None:
        """Set the streaming display mode."""
        self.stream_display_mode = mode
        logger.info(f"🎨 Stream display mode set to: {mode.value}")

    def set_auto_print_streaming(self, enabled: bool) -> None:
        """Enable or disable automatic printing of streaming output."""
        self.auto_print_streaming = enabled
        logger.info(f"🖨️ Auto-print streaming: {'enabled' if enabled else 'disabled'}")

    def clear_conversation_history(self) -> None:
        """Clear the conversation history by generating a new thread ID."""
        old_thread_id = self.thread_id
        self.thread_id = str(uuid.uuid4())
        logger.info(f"🧹 Cleared conversation history. New thread_id: {self.thread_id} (old: {old_thread_id})")

    def set_thread_id(self, thread_id: str) -> None:
        """Set a specific thread ID for conversation persistence."""
        old_thread_id = self.thread_id
        self.thread_id = thread_id
        logger.info(f"🔄 Thread ID changed from {old_thread_id} to {thread_id}")

    def set_config_provider(self, config_provider: AgentConfigurationProvider) -> None:
        """Set a new configuration provider for dynamic observability configuration."""
        old_provider = type(self.config_provider).__name__
        self.config_provider = config_provider
        new_provider = type(config_provider).__name__
        logger.info(f"🔧 Configuration provider changed: {old_provider} → {new_provider}")

    async def close(self) -> None:
        """Close the agent and clean up resources."""
        logger.info("🔌 Closing LangGraph agent and cleaning up resources...")

        try:
            if self.client:
                await self.client.close_all_sessions()

            self._langgraph_agent = None
            self._tools = []
            self._initialized = False

            if self.checkpointer:
                self.checkpointer = InMemorySaver() if self.memory_enabled else None

            logger.info("👋 LangGraph agent closed successfully")

        except Exception as e:
            logger.error(f"❌ Error during LangGraph agent closure: {e}")
            self._langgraph_agent = None
            self._tools = []
            self._initialized = False

    async def __aenter__(self):
        """Enter async context manager."""
        await self.initialize()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Exit async context manager."""
        await self.close()


# Alias for backward compatibility and easier imports
Agent = LangGraphAgent