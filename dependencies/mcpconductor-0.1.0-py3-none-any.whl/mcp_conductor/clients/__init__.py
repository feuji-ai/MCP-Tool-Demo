"""
Multi-server management for MCP integrations.

This module provides enterprise-grade multi-server orchestration,
managing multiple MCP servers and their lifecycles.
"""

from mcp_conductor.clients.client import MCPClient

__all__ = [
    "MCPClient",
]