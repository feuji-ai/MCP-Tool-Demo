# 👥 MCP Conductor Clients

**Multi-Server Orchestration - Managing Multiple MCP Servers Seamlessly**

The `clients` module provides **multi-server management** for MCP integrations. Think of it as the **"conductor of an orchestra"** - coordinating multiple MCP servers to work together harmoniously.

## 📁 Folder Structure

```
mcp_conductor/clients/
├── README.md                   # This documentation
├── __init__.py                 # Module exports
└── client.py                   # Multi-server management engine
```

## 🎯 What Does the Client Do?

### **Simple Analogy: Multi-Tool Workshop Manager**

**Without MCPClient** (Single tool approach):
```
You: "I need browser automation AND file operations"
You: *Manually manage Playwright MCP*
You: *Manually manage Filesystem MCP* 
You: *Manually coordinate everything*
```

**With MCPClient** (Orchestra conductor):
```
You: "I need browser automation AND file operations"
MCPClient: "I'll coordinate all the tools for you!"
MCPClient: *Manages browser + filesystem + any other MCP servers*
You: "Perfect! One unified interface to everything"
```

## 🏗️ Architecture Overview

```mermaid
graph TB
    subgraph "Application Layer"
        A[AI Agent] --> B[MCPClient]
    end
    
    subgraph "MCPClient Orchestration"
        B --> D[Configuration Manager]
        B --> E[Session Factory]
        B --> F[Lifecycle Manager]
    end
    
    subgraph "MCP Server Ecosystem"
        E --> J[MCPSession: Browser]
        E --> K[MCPSession: Files]  
        E --> L[MCPSession: Database]
        
        J --> N[Playwright MCP]
        K --> O[Filesystem MCP]
        L --> P[Custom MCP Server]
    end
    
    subgraph "Tool Aggregation"
        J --> R[Combined Tool Pool]
        K --> R
        L --> R
        R --> S[Agent Tool Interface]
    end
    
    style B fill:#ff9800,color:#fff
    style R fill:#4caf50,color:#fff
```

## 📄 File Documentation

### `client.py` - Multi-Server Management Engine

**Purpose**: Orchestrates multiple MCP servers, manages their lifecycles, and provides unified access to all available tools.

#### 🎯 Core Responsibilities

1. **🗂️ Configuration Management** - JSON/dict configs, server validation
2. **🔄 Session Lifecycle** - Parallel connection, health monitoring
3. **🛠️ Unified Tool Access** - Aggregates tools from all servers
4. **⚡ Enterprise Features** - Bulk operations, error isolation

## 🚀 Configuration Formats

### **JSON File Configuration**
```json
{
  "mcpServers": {
    "browser": {
      "command": "npx",
      "args": ["@playwright/mcp@latest"],
      "env": {"HEADLESS": "false"}
    },
    "files": {
      "command": "npx", 
      "args": ["@modelcontextprotocol/server-filesystem", "/workspace"]
    }
  }
}
```

### **Dictionary Configuration**
```python
config = {
    "mcpServers": {
        "browser": {"command": "npx", "args": ["@playwright/mcp@latest"]},
        "files": {"command": "npx", "args": ["@modelcontextprotocol/server-filesystem", "/tmp"]}
    }
}
```

## 💻 Usage Examples

### **Basic Multi-Server Setup**
```python
from mcp_conductor.clients import MCPClient
from mcp_conductor.agents import LangGraphAgent

# From config file
client = MCPClient.from_config_file("mcp_config.json")

# From dictionary
client = MCPClient.from_dict(config)

# Initialize all servers
await client.create_all_sessions()

# Use with agent (gets tools from ALL servers automatically)
agent = LangGraphAgent(llm=get_gemini_llm(), client=client)
```

### **Dynamic Server Management**
```python
# Start with empty client
client = MCPClient()

# Add servers dynamically
client.add_server("browser", {
    "command": "npx", "args": ["@playwright/mcp@latest"]
})

client.add_server("database", {
    "command": "python", "args": ["-m", "mcp_database"]
})

# Create sessions
await client.create_all_sessions()
```

### **Selective Server Control**
```python
# Create specific sessions only
await client.create_session("browser")
await client.create_session("files")

# Check what's active
active_servers = list(client.get_all_active_sessions().keys())
print(f"Active: {active_servers}")

# Clean shutdown
await client.close_all_sessions()
```

## 🔧 Key Methods

### **MCPClient Class**
```python
# Configuration
MCPClient.from_config_file(filepath)
MCPClient.from_dict(config)

# Server management
client.add_server(name, config)
client.remove_server(name)
client.get_server_names()

# Session lifecycle
await client.create_session(server_name)
await client.create_all_sessions()
await client.close_session(server_name)
await client.close_all_sessions()

# Access
client.get_session(server_name)
client.get_all_active_sessions()
```

## 🔍 Basic Troubleshooting

### **Common Issues**
```python
# Check configuration
server_names = client.get_server_names()
print(f"Configured: {server_names}")

# Check active sessions  
active = client.get_all_active_sessions()
print(f"Active: {list(active.keys())}")

# Test individual server
try:
    session = client.get_session("browser")
    tools = await session.list_tools()
    print(f"Browser tools: {len(tools)}")
except Exception as e:
    print(f"Browser error: {e}")
```

### **Health Monitoring**
```python
# Basic health check
for name, session in client.get_all_active_sessions().items():
    status = "🟢 Connected" if session.is_connected else "🔴 Disconnected"
    print(f"{name}: {status}")
```

## 💡 Best Practices

### **✅ Do:**
- Use descriptive server names (`browser_automation` not `server1`)
- Validate configurations before creating client
- Always cleanup with `close_all_sessions()`
- Handle partial failures gracefully

### **❌ Don't:**
- Hard-code sensitive data in configs
- Start unnecessary servers (impacts performance)
- Ignore connection failures
- Mix development and production configurations

## 🎯 When to Use MCPClient

### **Use MCPClient when you need:**
- **Multiple MCP servers** (browser + files + database)
- **Unified tool access** from all servers
- **Production reliability** with health monitoring
- **Complex workflows** requiring multiple tool types

### **Use single connectors when you need:**
- **Simple single-server** scenarios
- **Minimal dependencies** 
- **Custom connection logic**

## 💡 Key Takeaways

### **What MCPClient Does** 🎯
- **Orchestrates multiple MCP servers** into unified workflows
- **Manages configurations** with validation and error handling
- **Provides unified tool access** from all active servers
- **Handles server lifecycles** automatically

### **Why It Matters** 💪
- **Scalability**: Handle complex workflows requiring multiple tools
- **Reliability**: Robust error handling and recovery
- **Simplicity**: One interface for many servers
- **Flexibility**: Dynamic server management

**The MCPClient transforms multiple independent MCP servers into a cohesive, orchestrated system!** 🎼✨