# 🔌 MCP Conductor Connectors

**Transport Layer Abstraction for Model Context Protocol (MCP) Implementations**

The `connectors` module provides a clean abstraction layer over different MCP transport mechanisms, enabling seamless communication with MCP servers regardless of their underlying transport protocol (stdio, HTTP, WebSocket, etc.).

## 📁 Folder Structure

```
mcp_conductor/connectors/
├── __init__.py                 # Module exports
├── base.py                     # Abstract base connector interface
└── stdio.py                    # Standard I/O transport implementation
```

## 🏗️ Architecture Overview

```mermaid
graph TB
    subgraph "MCP Conductor Core"
        A[MCPSession] --> B[BaseConnector]
    end
    
    subgraph "Connector Layer"
        B --> C[StdioConnector]
        B --> D[HttpConnector] 
        B --> E[WebSocketConnector]
        
        style D fill:#f9f,stroke:#333,stroke-dasharray: 5 5
        style E fill:#f9f,stroke:#333,stroke-dasharray: 5 5
    end
    
    subgraph "Transport Layer"
        C --> F[StdioConnectionManager]
        D --> G[HttpConnectionManager]
        E --> H[WebSocketConnectionManager]
        
        style G fill:#f9f,stroke:#333,stroke-dasharray: 5 5
        style H fill:#f9f,stroke:#333,stroke-dasharray: 5 5
    end
    
    subgraph "MCP Ecosystem"
        F --> I[Playwright MCP<br/>Child Process]
        F --> J[Filesystem MCP<br/>Child Process]
        G --> K[HTTP MCP Server]
        H --> L[WebSocket MCP Server]
        
        style K fill:#f9f,stroke:#333,stroke-dasharray: 5 5
        style L fill:#f9f,stroke:#333,stroke-dasharray: 5 5
    end
    
    style A fill:#2196f3,color:#fff
    style B fill:#ff9800,color:#fff
    style C fill:#4caf50,color:#fff
    style F fill:#9c27b0,color:#fff
```

*Note: Dashed boxes indicate future implementations*

## 📄 File Documentation

### `__init__.py` - Module Exports

**Purpose**: Clean public API for the connectors module.

```python
from mcp_conductor.connectors.base import BaseConnector
from mcp_conductor.connectors.stdio import StdioConnector

__all__ = [
    "BaseConnector",
    "StdioConnector",
]
```

**Usage**:
```python
from mcp_conductor.connectors import BaseConnector, StdioConnector
```

---

### `base.py` - Abstract Base Connector ⭐

**Purpose**: Defines the universal interface that all MCP transport implementations must follow.

#### 🎯 Key Responsibilities

1. **🔄 Connection Lifecycle Management**
   - Abstract connection establishment
   - Automatic reconnection on connection loss
   - Graceful resource cleanup

2. **🛠️ MCP Protocol Operations**
   - Tool discovery and execution
   - Resource reading and listing
   - Prompt management
   - Session initialization

3. **🔧 Session State Management**
   - Connection health monitoring
   - Capability detection
   - Auto-refresh on server notifications

4. **⚡ Enterprise Features**
   - Connection pooling support
   - Retry mechanisms
   - Comprehensive error handling
   - Observability hooks

#### 🔍 Core Interface Methods

```python
class BaseConnector(ABC):
    # Connection Management
    @abstractmethod
    async def connect(self) -> None: ...
    
    @property 
    @abstractmethod
    def public_identifier(self) -> str: ...
    
    # MCP Operations
    async def call_tool(self, name: str, arguments: dict) -> CallToolResult: ...
    async def list_tools(self) -> list[Tool]: ...
    async def list_resources(self) -> list[Resource]: ...
    async def list_prompts(self) -> list[Prompt]: ...
    async def read_resource(self, uri: AnyUrl) -> ReadResourceResult: ...
    async def get_prompt(self, name: str, arguments: dict) -> GetPromptResult: ...
```

#### 🚀 Advanced Features

**Auto-Reconnection Logic**:
```python
async def _ensure_connected(self) -> None:
    """Intelligent reconnection with exponential backoff."""
    if not self.is_connected:
        if self.auto_reconnect:
            logger.debug("Connection lost, attempting to reconnect...")
            await self.connect()
        else:
            raise RuntimeError("Connection lost. Auto-reconnection disabled.")
```

**Connection Health Monitoring**:
```python
@property
def is_connected(self) -> bool:
    """Multi-layer connection health check."""
    # 1. Check basic connected flag
    # 2. Verify connection manager task status  
    # 3. Validate stream health (for stdio)
    # 4. Handle edge cases gracefully
```

**Deprecation Warnings for Data Freshness**:
```python
@property
def tools(self) -> list[Tool]:
    warnings.warn(
        "The 'tools' property may return stale data. "
        "Use 'await list_tools()' for fresh data.",
        DeprecationWarning
    )
```

---

### `stdio.py` - Standard I/O Connector

**Purpose**: Implements MCP communication for subprocess-based MCP servers (most common).

#### 🎯 Core Features

1. **📟 Subprocess Management**
   - Child process lifecycle
   - Standard I/O stream handling
   - Environment variable passing
   - Command-line argument support

2. **🔧 StdIO Protocol Handling**
   - JSON-RPC over stdio streams
   - Bidirectional communication
   - Stream error handling
   - Process cleanup on disconnect

3. **🛡️ Robust Error Handling**
   - Process crash detection
   - Stream closure handling
   - Graceful degradation
   - Resource leak prevention

#### 💻 Implementation Details

**Initialization**:
```python
connector = StdioConnector(
    command="npx",
    args=["@playwright/mcp@latest", "--isolated"],
    env={"BROWSER": "chromium"},
    errlog=sys.stderr
)
```

**Connection Manager Integration**:
```python
async def connect(self) -> None:
    # Create server parameters
    server_params = StdioServerParameters(
        command=self.command, 
        args=self.args, 
        env=self.env
    )
    
    # Use connection manager for proper lifecycle
    self._connection_manager = StdioConnectionManager(server_params, self.errlog)
    read_stream, write_stream = await self._connection_manager.start()
    
    # Create MCP client session
    self.client_session = ClientSession(read_stream, write_stream, ...)
```

**Public Identifier**:
```python
@property
def public_identifier(self) -> str:
    return {
        "type": "stdio", 
        "command&args": f"{self.command} {' '.join(self.args)}"
    }
```

## 🚀 Usage Examples

### Basic StdIO Connector

```python
from mcp_conductor.connectors import StdioConnector

# Create connector for Playwright MCP
connector = StdioConnector(
    command="npx",
    args=["@playwright/mcp@latest"],
    env={"HEADLESS": "false"}
)

# Use with session
from mcp_conductor.sessions.session import MCPSession

session = MCPSession(connector)
async with session:
    tools = await session.list_tools()
    result = await session.call_tool("navigate", {"url": "https://example.com"})
```

### Advanced Configuration

```python
# Custom error logging
import sys
from io import StringIO

error_buffer = StringIO()
connector = StdioConnector(
    command="npx",
    args=["@playwright/mcp@latest", "--isolated"],
    env={
        "DEBUG": "mcp:*",
        "BROWSER": "chromium",
        "VIEWPORT": "1920x1080"
    },
    errlog=error_buffer  # Capture errors for analysis
)
```

### Multi-Connector Setup

```python
# Different MCP servers for different capabilities
connectors = {
    "browser": StdioConnector(
        command="npx", 
        args=["@playwright/mcp@latest"]
    ),
    "filesystem": StdioConnector(
        command="npx", 
        args=["@modelcontextprotocol/server-filesystem", "/workspace"]
    ),
    "git": StdioConnector(
        command="python", 
        args=["-m", "mcp_git", "--repository", "/project"]
    )
}
```

## 🔧 Extending the Connector System

### Creating Custom Connectors

```python
from mcp_conductor.connectors.base import BaseConnector
from mcp_conductor.managers.base import ConnectionManager

class HttpConnector(BaseConnector):
    """HTTP-based MCP connector for web services."""
    
    def __init__(self, base_url: str, api_key: str = None):
        super().__init__()
        self.base_url = base_url
        self.api_key = api_key
    
    async def connect(self) -> None:
        # Implement HTTP connection logic
        # Create HTTP client session
        # Establish MCP-over-HTTP connection
        pass
    
    @property
    def public_identifier(self) -> str:
        return {"type": "http", "url": self.base_url}

class WebSocketConnector(BaseConnector):
    """WebSocket-based MCP connector for real-time services."""
    
    async def connect(self) -> None:
        # Implement WebSocket connection logic
        pass
```

### Integration with Connection Managers

```python
from mcp_conductor.managers.base import ConnectionManager

class HttpConnectionManager(ConnectionManager[aiohttp.ClientSession]):
    """HTTP connection lifecycle management."""
    
    async def _establish_connection(self) -> aiohttp.ClientSession:
        return aiohttp.ClientSession(
            connector=aiohttp.TCPConnector(limit=100),
            timeout=aiohttp.ClientTimeout(total=30)
        )
    
    async def _close_connection(self) -> None:
        if self._connection:
            await self._connection.close()
```

## 🎯 Design Principles

### 1. **Transport Agnostic**
- Abstract interface supports any transport protocol
- Implementation details hidden from higher layers
- Easy to add new transport types

### 2. **Robust Connection Management**
- Automatic reconnection with exponential backoff
- Connection health monitoring
- Graceful degradation on failures

### 3. **Production Ready**
- Comprehensive error handling
- Resource leak prevention
- Observability hooks for monitoring

### 4. **Developer Friendly**
- Clear separation of concerns
- Extensive documentation
- Rich error messages

## 📊 Connector Lifecycle

```mermaid
sequenceDiagram
    participant App as Application
    participant Session as MCPSession
    participant Connector as BaseConnector
    participant Manager as ConnectionManager
    participant MCP as MCP Server
    
    App->>Session: Create with connector
    Session->>Connector: connect()
    Connector->>Manager: start()
    Manager->>MCP: Launch process/connect
    MCP->>Manager: Streams ready
    Manager->>Connector: Return streams
    Connector->>Session: Connected
    
    Note over App,MCP: Normal Operations
    Session->>Connector: call_tool()
    Connector->>MCP: Execute tool
    MCP->>Connector: Tool result
    Connector->>Session: Formatted result
    
    Note over App,MCP: Connection Lost
    MCP--xConnector: Connection drops
    Connector->>Connector: Auto-reconnect
    Connector->>Manager: restart()
    Manager->>MCP: Reconnect
    
    Note over App,MCP: Cleanup
    App->>Session: close()
    Session->>Connector: disconnect()
    Connector->>Manager: stop()
    Manager->>MCP: Terminate/close
```

## 🔗 Integration Points

### With MCPSession
```python
session = MCPSession(connector, auto_connect=True)
# Session uses connector for all MCP operations
```

### With MCPClient
```python
# Client creates connectors from configuration
connector = create_connector_from_config(server_config)
session = MCPSession(connector)
```

### With Connection Managers
```python
# Connectors delegate lifecycle to managers
self._connection_manager = StdioConnectionManager(params)
streams = await self._connection_manager.start()
```

---

## 🚀 Future Roadmap

### Planned Connectors
- **HttpConnector** - REST API-based MCP servers
- **WebSocketConnector** - Real-time MCP communication  
- **GrpcConnector** - High-performance binary protocol
- **SshConnector** - Remote MCP servers over SSH

### Enhanced Features
- **Connection Pooling** - Reuse connections across sessions
- **Load Balancing** - Distribute calls across multiple servers
- **Circuit Breakers** - Prevent cascade failures
- **Metrics Collection** - Performance monitoring

The connectors module provides the foundation for reliable, scalable MCP integration that can grow with your application's needs.