"""
Core utilities and shared functionality for MCP Conductor.

Essential utilities including error formatting, logging configuration,
and common patterns used throughout the system.
"""

from mcp_conductor.core.exceptions import format_error
from mcp_conductor.core.logging import get_logger, logger, set_debug, MCP_CONDUCTOR_DEBUG
from mcp_conductor.core.utils import singleton

__all__ = [
    # Error handling
    "format_error",

    # Logging
    "get_logger",
    "logger",
    "set_debug",
    "MCP_CONDUCTOR_DEBUG",

    # Utilities
    "singleton",
]