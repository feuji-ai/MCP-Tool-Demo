# ⚙️ MCP Conductor Core

**Essential Utilities & Shared Functionality - The Foundation Layer**

The `core` module provides **fundamental utilities** that support the entire MCP Conductor ecosystem. Think of it as the **"toolbox and foundation"** that everything else builds upon.

## 📁 Folder Structure

```
mcp_conductor/core/
├── README.md                   # This documentation
├── __init__.py                 # Module exports
├── exceptions.py               # LLM-friendly error formatting
├── logging.py                  # Debug logging configuration
└── utils.py                    # Utility functions & patterns
```

## 🎯 What Does Core Provide?

### **Simple Analogy: The Workshop Foundation**

Think of building a workshop:

```
🏗️ Foundation (core)     → Concrete, electrical, plumbing
🔧 Tools (adapters)      → Built on the foundation
🤖 Workers (agents)      → Use the tools
🏢 Management (clients)  → Coordinate everything
```

**Core provides the essential "plumbing" that everything else depends on**:
- **Error Handling**: When things go wrong, format errors clearly
- **Logging**: Track what's happening for debugging
- **Utilities**: Common patterns used everywhere

## 📄 File Documentation

### `__init__.py` - Module Exports

```python
from mcp_conductor.core.exceptions import format_error
from mcp_conductor.core.logging import get_logger, logger, set_debug, MCP_CONDUCTOR_DEBUG
from mcp_conductor.core.utils import singleton

__all__ = [
    "format_error",
    "get_logger", 
    "logger",
    "set_debug",
    "MCP_CONDUCTOR_DEBUG",
    "singleton",
]
```

---

### `exceptions.py` - LLM-Friendly Error Formatting ⭐

**Purpose**: Converts Python exceptions into structured, LLM-readable error messages.

#### 🎯 **The Problem It Solves**

**Without error formatting**:
```python
# Raw Python error (confusing for LLMs)
TimeoutError: Connection timeout after 30 seconds at line 42 in connector.py
```

**With error formatting**:
```python
# LLM-friendly structured error
{
    "error": "TimeoutError",
    "details": "Connection timeout after 30 seconds", 
    "isRetryable": True,
    "code": "TIMEOUT",
    "tool": "playwright_navigate"
}
```

#### 🔧 **Core Function**

```python
def format_error(error: Exception, **context) -> dict:
    """Format exception into LLM-readable structure."""
    
    formatted_context = {
        "error": type(error).__name__,
        "details": str(error),
        "isRetryable": isinstance(error, retryable_exceptions),
        "stack": traceback.format_exc(),
        "code": getattr(error, "code", "UNKNOWN"),
    }
    formatted_context.update(context)  # Add extra context
    
    return formatted_context
```

#### 💻 **Usage Examples**

```python
from mcp_conductor.core import format_error

# Basic error formatting
try:
    await some_mcp_operation()
except Exception as e:
    error_info = format_error(e)
    return error_info  # LLM can understand this

# With additional context
try:
    await session.call_tool("navigate", {"url": url})
except Exception as e:
    error_info = format_error(e, tool="navigate", url=url)
    return error_info
```

#### 🎯 **Retryable Exceptions**

```python
# These errors can be retried
retryable_exceptions = (TimeoutError, ConnectionError)

# Usage in tools
if error_info["isRetryable"]:
    await asyncio.sleep(1)
    return await retry_operation()
```

---

### `logging.py` - Debug Logging Configuration ⭐

**Purpose**: Centralized logging configuration with debug levels and module-specific loggers.

#### 🎯 **Key Features**

1. **Debug Levels**: Control verbosity with environment variables
2. **Module Loggers**: Different loggers for different parts
3. **Clean Configuration**: Simple setup and usage
4. **Environment Aware**: Automatically reads debug settings

#### 🔧 **Debug Levels**

```python
MCP_CONDUCTOR_DEBUG = 0  # WARNING only
MCP_CONDUCTOR_DEBUG = 1  # INFO level (default)
MCP_CONDUCTOR_DEBUG = 2  # DEBUG level (verbose)
```

#### 💻 **Usage Examples**

**Basic Logging**:
```python
from mcp_conductor.core import logger

# Use the default logger
logger.info("Agent initialization complete")
logger.warning("Connection unstable, retrying...")
logger.error("Failed to connect to MCP server")
```

**Module-Specific Loggers**:
```python
from mcp_conductor.core import get_logger

# Create logger for specific module
adapter_logger = get_logger("adapters")
session_logger = get_logger("sessions")

adapter_logger.debug("Converting MCP tool to LangChain format")
session_logger.info("MCP session established successfully")
```

**Dynamic Debug Control**:
```python
from mcp_conductor.core import set_debug

# Change debug level at runtime
set_debug(2)  # Enable verbose debugging
set_debug(0)  # Quiet mode (warnings only)
```

**Environment Configuration**:
```bash
# Set via environment variable
export MCP_CONDUCTOR_DEBUG=2  # Verbose debugging
export MCP_CONDUCTOR_DEBUG=1  # Standard info
export MCP_CONDUCTOR_DEBUG=0  # Warnings only
```

#### 🔧 **Logger Configuration**

```python
# Automatic configuration based on debug level
configure()  # Called automatically on import

# Manual configuration
logger = get_logger("my_module")
logger.setLevel(logging.DEBUG)
```

---

### `utils.py` - Utility Functions & Patterns ⚙️

**Purpose**: Common utility functions and design patterns used throughout the codebase.

#### 🎯 **Current Utilities**

**Singleton Decorator**:
```python
@singleton
class DatabaseConnection:
    def __init__(self):
        self.connection = create_connection()

# Only one instance ever created
db1 = DatabaseConnection()
db2 = DatabaseConnection()
assert db1 is db2  # Same instance
```

#### 💻 **Usage Examples**

**Singleton Pattern**:
```python
from mcp_conductor.core import singleton

@singleton
class ConfigManager:
    def __init__(self):
        self.config = load_config()
        self.cache = {}
    
    def get_setting(self, key):
        return self.config.get(key)

# Everywhere in your code, same instance
config1 = ConfigManager()
config2 = ConfigManager()
# config1 is config2 → True
```

**Real-World Example**:
```python
@singleton
class MCPServerRegistry:
    """Global registry of available MCP servers."""
    
    def __init__(self):
        self.servers = {}
        self.discovery_cache = {}
    
    def register_server(self, name, config):
        self.servers[name] = config
    
    def discover_servers(self):
        # Expensive operation, only do once
        if not self.discovery_cache:
            self.discovery_cache = self._scan_for_servers()
        return self.discovery_cache

# Used throughout the system
registry = MCPServerRegistry()  # Always same instance
```

## 🔄 How Core Components Work Together

### **Error Flow Example**

```python
# In adapter.py
from mcp_conductor.core import format_error, get_logger

logger = get_logger("adapters")

class ToolAdapter:
    async def _arun(self, **kwargs):
        try:
            logger.debug(f"Executing tool with args: {kwargs}")
            result = await self.tool_session.call_tool(self.name, kwargs)
            logger.info(f"Tool {self.name} completed successfully")
            return result
            
        except Exception as e:
            logger.error(f"Tool {self.name} failed: {e}")
            
            # Format error for LLM
            return format_error(e, tool=self.name, args=kwargs)
```

### **Logging Hierarchy**

```
mcp_conductor (root logger)
├── adapters (tool conversion)
├── agents (AI agents)  
├── clients (multi-server)
├── sessions (individual servers)
├── connectors (transport)
└── managers (connection lifecycle)
```

### **Debug Output Example**

```bash
# With MCP_CONDUCTOR_DEBUG=2
2024-12-25 10:30:15 - mcp_conductor.adapters - DEBUG - Converting tool: playwright_navigate
2024-12-25 10:30:15 - mcp_conductor.sessions - INFO - MCP session initialized with 5 tools
2024-12-25 10:30:16 - mcp_conductor.agents - INFO - Agent ready with tools: navigate, click, screenshot
2024-12-25 10:30:17 - mcp_conductor.adapters - ERROR - Tool execution failed: TimeoutError
```

## 🎯 Integration Points

### **With Adapters**
```python
# Tool adapters use error formatting and logging
if self.handle_tool_error:
    return format_error(e, tool=self.name)
```

### **With Agents**
```python
# Agents use logging for execution tracking
logger.info(f"💬 Received query: '{display_query}'")
logger.info(f"🏃 Starting agent execution")
```

### **With Connectors**
```python
# Connectors use logging for connection status
logger.debug("Successfully connected to MCP implementation")
logger.warning(f"Error closing stdio context: {e}")
```

## 🔧 Configuration Best Practices

### **Development Setup**
```bash
# Verbose debugging for development
export MCP_CONDUCTOR_DEBUG=2
```

### **Production Setup**
```bash
# Minimal logging for production
export MCP_CONDUCTOR_DEBUG=0
```

### **Custom Logger Setup**
```python
# For specific modules that need custom handling
from mcp_conductor.core import get_logger

custom_logger = get_logger("my_custom_module")
custom_logger.setLevel(logging.WARNING)  # Only warnings and errors
```

## 🚀 Extending Core Utilities

### **Adding New Utilities**

```python
# In utils.py - add new utility functions
def retry_with_backoff(max_retries: int = 3):
    """Decorator for automatic retry with exponential backoff."""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            for attempt in range(max_retries):
                try:
                    return await func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_retries - 1:
                        raise
                    await asyncio.sleep(2 ** attempt)
            return wrapper
    return decorator
```

### **Adding New Error Types**

```python
# In exceptions.py - extend retryable exceptions
retryable_exceptions = (
    TimeoutError, 
    ConnectionError,
    TemporaryMCPError,  # New custom error type
)
```

## 💡 Key Takeaways

### **What Core Provides** 🎯
- **Error Translation**: Python exceptions → LLM-friendly messages
- **Centralized Logging**: Consistent debug output across all modules
- **Common Patterns**: Singleton and other utilities
- **Foundation Services**: Essential plumbing for the whole system

### **Why It Matters** 💪
- **Debuggability**: Clear logging helps identify issues quickly
- **User Experience**: Structured errors help LLMs handle failures gracefully
- **Code Quality**: Common patterns reduce duplication
- **Maintainability**: Centralized utilities are easier to update

### **The Big Picture** 🌟
Core is the **"invisible foundation"** that makes everything else work smoothly. You rarely interact with it directly, but it's essential for **reliability**, **debuggability**, and **maintainability**.

Think of it as the **"electrical and plumbing system"** of a house - you don't see it, but nothing works without it! 🏠⚡