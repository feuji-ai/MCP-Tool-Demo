"""
Error formatting for mcp_conductor.

Formats exceptions into structured format that can be understood by LLMs,
following mcp_use patterns exactly.
"""

import traceback
from mcp_conductor.core.logging import logger

# Retryable exceptions - operations that might succeed if retried
retryable_exceptions = (TimeoutError, ConnectionError)


def format_error(error: Exception, **context) -> dict:
    """
    Formats an exception into a structured format that can be understood by LLMs.

    Args:
        error: The exception to format.
        **context: Additional context to include in the formatted error.

    Returns:
        A dictionary containing the formatted error.
    """
    formatted_context = {
        "error": type(error).__name__,
        "details": str(error),
        "isRetryable": isinstance(error, retryable_exceptions),
        "stack": traceback.format_exc(),
        "code": getattr(error, "code", "UNKNOWN"),
    }
    formatted_context.update(context)

    logger.error(f"Structured error: {formatted_context}")
    return formatted_context