"""
Logging configuration for mcp_conductor.

Simple logging setup following mcp_use patterns with debug levels
and minimal configuration overhead.
"""

import logging
import os
import sys

# Global debug flag - can be set programmatically or from environment
MCP_CONDUCTOR_DEBUG = 1

# Default log format
DEFAULT_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

# Module-specific loggers
_loggers = {}


def get_logger(name: str = "mcp_conductor") -> logging.Logger:
    """Get a logger instance for the specified name.

    Args:
        name: Logger name, usually the module name

    Returns:
        Configured logger instance
    """
    if name in _loggers:
        return _loggers[name]

    # Create new logger
    logger = logging.getLogger(name)
    _loggers[name] = logger
    return logger


def configure():
    """Configure the root mcp_conductor logger based on debug level."""
    root_logger = get_logger()

    # Set level based on debug settings
    if MCP_CONDUCTOR_DEBUG == 2:
        level = logging.DEBUG
    elif MCP_CONDUCTOR_DEBUG == 1:
        level = logging.INFO
    else:
        level = logging.WARNING

    root_logger.setLevel(level)

    # Clear existing handlers
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)

    # Add console handler
    console_handler = logging.StreamHandler(sys.stdout)
    formatter = logging.Formatter(DEFAULT_FORMAT)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)


def set_debug(debug_level: int = 2) -> None:
    """Set the debug flag and update log level.

    Args:
        debug_level: Debug level (0=warning, 1=info, 2=debug)
    """
    global MCP_CONDUCTOR_DEBUG
    MCP_CONDUCTOR_DEBUG = debug_level

    # Update log level for existing loggers
    if debug_level == 2:
        for logger in _loggers.values():
            logger.setLevel(logging.DEBUG)
    elif debug_level == 1:
        for logger in _loggers.values():
            logger.setLevel(logging.INFO)
    else:
        for logger in _loggers.values():
            logger.setLevel(logging.WARNING)


# Check environment variable for debug flag
debug_env = os.environ.get("MCP_CONDUCTOR_DEBUG", "").lower()
if debug_env == "2":
    MCP_CONDUCTOR_DEBUG = 2
elif debug_env == "1":
    MCP_CONDUCTOR_DEBUG = 1

# Configure default logger
configure()

# Create default logger instance
logger = get_logger()