"""
Connection managers for MCP transport lifecycle.

This module provides low-level connection managers that handle
subprocess and network connection lifecycles, following mcp_use
patterns for persistent session management.
"""

from mcp_conductor.managers.base import ConnectionManager
from mcp_conductor.managers.stdio import StdioConnectionManager

__all__ = [
    "ConnectionManager",
    "StdioConnectionManager",
]