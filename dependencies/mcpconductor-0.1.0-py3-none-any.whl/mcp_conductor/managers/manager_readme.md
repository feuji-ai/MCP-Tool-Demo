# 🎛️ MCP Conductor Managers

**Connection Lifecycle Management for Reliable MCP Communication**

The `managers` module handles the **low-level plumbing** of keeping connections alive, healthy, and properly cleaned up. Think of managers as the **"IT support team"** that keeps your internet connection running smoothly while you focus on your work.

## 📁 Folder Structure

```
mcp_conductor/managers/
├── __init__.py                 # Module exports
├── base.py                     # Abstract connection manager interface
└── stdio.py                    # StdIO connection lifecycle manager
```

## 🏗️ Architecture Overview

```mermaid
graph TB
    subgraph "Connector Layer"
        A[StdioConnector] --> B[StdioConnectionManager]
        C[HttpConnector] --> D[HttpConnectionManager]
        E[WebSocketConnector] --> F[WebSocketConnectionManager]
        
        style C fill:#f9f,stroke:#333,stroke-dasharray: 5 5
        style D fill:#f9f,stroke:#333,stroke-dasharray: 5 5
        style E fill:#f9f,stroke:#333,stroke-dasharray: 5 5
        style F fill:#f9f,stroke:#333,stroke-dasharray: 5 5
    end
    
    subgraph "Manager Layer (The IT Support Team)"
        B --> G[Process Lifecycle]
        B --> H[Stream Health]
        B --> I[Auto Recovery]
        B --> J[Resource Cleanup]
    end
    
    subgraph "Actual Connections"
        G --> K[npx @playwright/mcp]
        H --> L[stdin/stdout streams]
        I --> M[Process monitoring]
        J --> N[Graceful shutdown]
    end
    
    style A fill:#4caf50,color:#fff
    style B fill:#ff9800,color:#fff
    style G fill:#2196f3,color:#fff
    style K fill:#9c27b0,color:#fff
```

## 🎯 What Do Managers Actually Do?

### **Simple Analogy: The Internet Connection Manager**

Think of your home WiFi router's job:

```
You: "I want to watch Netflix"
Router Manager: 
  1. ✅ Check if internet connection is alive
  2. ✅ If down, try to reconnect automatically  
  3. ✅ Handle network traffic properly
  4. ✅ Clean up old connections
  5. ✅ Monitor for problems
You: "Netflix is working perfectly!" (You don't see the complexity)
```

**Managers do the same thing for MCP connections**:

```
Connector: "I want to talk to the browser tool"
Manager:
  1. ✅ Launch the npx process properly
  2. ✅ Monitor if process crashes
  3. ✅ Handle stdin/stdout streams safely
  4. ✅ Restart process if it dies
  5. ✅ Clean up when done
Connector: "Browser tool is ready!" (Doesn't see the complexity)
```

## 📄 File Documentation

### `__init__.py` - Module Exports

**Purpose**: Clean API for importing manager classes.

```python
from mcp_conductor.managers.base import ConnectionManager
from mcp_conductor.managers.stdio import StdioConnectionManager

__all__ = [
    "ConnectionManager",
    "StdioConnectionManager",
]
```

**Usage**:
```python
from mcp_conductor.managers import ConnectionManager, StdioConnectionManager
```

---

### `base.py` - Abstract Connection Manager ⭐

**Purpose**: The "blueprint" that all connection managers must follow.

#### 🎯 Key Responsibilities

1. **🔄 Task Isolation**
   - Prevents "cancel scope in different task" errors
   - Runs connections in dedicated async tasks
   - Proper cleanup on cancellation

2. **📡 Event-Driven Lifecycle**
   - `_ready_event` - Connection is established
   - `_done_event` - Connection is fully closed
   - Exception handling and propagation

3. **🛡️ Robust State Management**
   - Connection health monitoring
   - Graceful startup and shutdown
   - Error isolation and recovery

#### 🔍 Core Interface

```python
class ConnectionManager(Generic[T], ABC):
    @abstractmethod
    async def _establish_connection(self) -> T:
        """Create the actual connection (implement this)"""
        pass
    
    @abstractmethod  
    async def _close_connection(self) -> None:
        """Close the connection properly (implement this)"""
        pass
    
    # Provided by base class:
    async def start(self) -> T: ...      # Start and wait for ready
    async def stop(self) -> None: ...    # Stop and cleanup
    def get_streams(self) -> T: ...      # Get current connection
```

#### 🚀 The Magic: Task Isolation

**Problem Without Managers**:
```python
# This causes "cancel scope in different task" errors
async def bad_approach():
    async with stdio_client(params) as (read, write):
        # If this task gets cancelled while stdio_client is running
        # in a different task, you get nasty errors
        await do_work(read, write)
```

**Solution With Managers**:
```python
# Manager runs stdio_client in isolated task
async def good_approach():
    manager = StdioConnectionManager(params)
    read, write = await manager.start()  # Safe task isolation
    try:
        await do_work(read, write)
    finally:
        await manager.stop()  # Proper cleanup
```

#### 🔧 Lifecycle Management

```python
async def _connection_task(self) -> None:
    """The heart of the manager - runs in isolated task."""
    try:
        # 1. Establish connection
        self._connection = await self._establish_connection()
        
        # 2. Signal ready
        self._ready_event.set()
        
        # 3. Keep alive until cancelled
        await asyncio.Event().wait()  # Wait forever
        
    except Exception as e:
        self._exception = e
        self._ready_event.set()  # Signal ready (with error)
        
    finally:
        # 4. Always cleanup
        await self._close_connection()
        self._done_event.set()
```

---

### `stdio.py` - StdIO Connection Manager

**Purpose**: Manages the lifecycle of `npx` processes and their stdin/stdout streams.

#### 🎯 Core Features

1. **📟 Process Lifecycle**
   - Launches child processes safely
   - Monitors process health
   - Handles process crashes gracefully

2. **🔧 Stream Management**
   - Manages stdin/stdout communication
   - Detects stream closures
   - Provides clean stream interfaces

3. **🛡️ Error Recovery**
   - Process crash detection
   - Automatic cleanup on failures
   - Resource leak prevention

#### 💻 Implementation Details

**Initialization**:
```python
manager = StdioConnectionManager(
    server_params=StdioServerParameters(
        command="npx",
        args=["@playwright/mcp@latest", "--isolated"],
        env={"DEBUG": "mcp:*"}
    ),
    errlog=sys.stderr  # Where to send error output
)
```

**Connection Establishment**:
```python
async def _establish_connection(self) -> tuple[Any, Any]:
    """Launch the npx process and return streams."""
    
    # Create the stdio_client context manager
    self._stdio_ctx = stdio_client(self.server_params, self.errlog)
    
    # Enter the context (launches process)
    read_stream, write_stream = await self._stdio_ctx.__aenter__()
    
    return read_stream, write_stream
```

**Cleanup Process**:
```python
async def _close_connection(self) -> None:
    """Properly close the process and streams."""
    if self._stdio_ctx:
        try:
            # Exit the context manager (kills process)
            await self._stdio_ctx.__aexit__(None, None, None)
        except Exception as e:
            logger.warning(f"Error closing stdio context: {e}")
        finally:
            self._stdio_ctx = None
```

## 🚀 Usage Examples

### Basic Manager Usage

```python
from mcp_conductor.managers import StdioConnectionManager
from mcp import StdioServerParameters

# Create manager
params = StdioServerParameters(
    command="npx",
    args=["@playwright/mcp@latest"],
    env={"HEADLESS": "false"}
)

manager = StdioConnectionManager(params)

# Use the manager
try:
    # Start the connection
    read_stream, write_stream = await manager.start()
    
    # Use the streams for MCP communication
    # (Usually done by the connector layer)
    
finally:
    # Always cleanup
    await manager.stop()
```

### Integration with Connectors

```python
# How StdioConnector uses StdioConnectionManager
class StdioConnector(BaseConnector):
    async def connect(self) -> None:
        # Create manager
        self._connection_manager = StdioConnectionManager(
            server_params, 
            self.errlog
        )
        
        # Start and get streams
        read_stream, write_stream = await self._connection_manager.start()
        
        # Create MCP client session with streams
        self.client_session = ClientSession(
            read_stream, 
            write_stream,
            # ... other params
        )
```

### Error Handling Example

```python
async def robust_connection():
    manager = StdioConnectionManager(params)
    
    try:
        streams = await manager.start()
        logger.info("✅ Connection established")
        
        # Use the connection
        await do_mcp_work(streams)
        
    except Exception as e:
        logger.error(f"❌ Connection failed: {e}")
        # Manager handles cleanup automatically
        
    finally:
        await manager.stop()
        logger.info("🧹 Connection cleaned up")
```

## 🔧 Advanced Features

### Connection Health Monitoring

```python
# Managers provide connection health info
if manager.get_streams():
    read_stream, write_stream = manager.get_streams()
    
    # Check if streams are still alive
    if hasattr(read_stream, '_closed') and read_stream._closed:
        logger.warning("Read stream is closed!")
        
    if hasattr(write_stream, '_closed') and write_stream._closed:
        logger.warning("Write stream is closed!")
```

### Custom Error Handling

```python
# Manager catches and stores exceptions
try:
    streams = await manager.start()
except Exception as e:
    # Exception was caught and stored by manager
    logger.error(f"Connection failed: {e}")
    
    # Manager is still in clean state for retry
    await asyncio.sleep(1)
    streams = await manager.start()  # Can retry
```

### Process Monitoring

```python
# Check if the background task is still running
if hasattr(manager, '_task') and manager._task:
    if manager._task.done():
        logger.warning("Manager task completed unexpectedly")
        # Handle reconnection logic
```

## 🎯 Design Principles

### 1. **Task Isolation**
- Each connection runs in its own async task
- Prevents cancellation scope errors
- Clean separation of concerns

### 2. **Event-Driven Design**
- Clear lifecycle events (`ready`, `done`)
- Exception propagation
- Non-blocking state management

### 3. **Resource Safety**
- Guaranteed cleanup on exit
- Exception-safe resource management
- No resource leaks

### 4. **Error Transparency**
- Exceptions bubble up clearly
- Detailed error logging
- Graceful degradation

## 📊 Manager Lifecycle

```mermaid
sequenceDiagram
    participant Connector
    participant Manager
    participant Task
    participant Process
    
    Connector->>Manager: start()
    Manager->>Task: create_task(_connection_task)
    Task->>Process: launch npx process
    Process->>Task: streams ready
    Task->>Manager: _ready_event.set()
    Manager->>Connector: return streams
    
    Note over Connector,Process: Normal Operation
    Connector->>Manager: get_streams()
    Manager->>Connector: return current streams
    
    Note over Connector,Process: Shutdown
    Connector->>Manager: stop()
    Manager->>Task: cancel()
    Task->>Process: terminate process
    Process->>Task: cleanup complete
    Task->>Manager: _done_event.set()
    Manager->>Connector: shutdown complete
```

## 🧪 Testing Managers

### Unit Test Example

```python
async def test_stdio_manager():
    params = StdioServerParameters(
        command="npx",
        args=["@playwright/mcp@latest"]
    )
    
    manager = StdioConnectionManager(params)
    
    try:
        # Test connection
        streams = await manager.start()
        assert streams is not None
        assert len(streams) == 2  # read, write
        
        # Test health
        current_streams = manager.get_streams()
        assert current_streams == streams
        
    finally:
        await manager.stop()
        
        # Verify cleanup
        assert manager.get_streams() is None
```

## 💡 Key Takeaways

### **What Managers Do** 🎯
- **Handle the "boring but critical" stuff** that connectors shouldn't worry about
- **Prevent common async pitfalls** like task cancellation errors
- **Provide reliable connection lifecycle** with proper cleanup
- **Monitor connection health** and provide status information

### **Why They Matter** 💪
- **Reliability**: Connections don't randomly break or leak resources
- **Simplicity**: Connectors focus on MCP protocol, not process management
- **Robustness**: Proper error handling and recovery mechanisms
- **Performance**: Efficient resource usage and cleanup

### **The Big Picture** 🌟
Managers are the **invisible infrastructure** that makes everything else work smoothly. You rarely interact with them directly, but they're the reason your MCP connections are rock-solid and don't cause weird async errors or resource leaks.

Think of them as the **"plumbing"** - when it works well, you never think about it! 🔧✨