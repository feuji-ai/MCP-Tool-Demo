"""
Langfuse observability for mcp_conductor.

Langfuse integration following mcp_use patterns exactly with global
variables and direct trace functionality using the new Langfuse SDK v3 API.
"""

from mcp_conductor.core.logging import logger
import os
from dotenv import load_dotenv

load_dotenv()

# Check if Langfuse is disabled via environment variable
_langfuse_disabled = os.getenv("MCP_CONDUCTOR_LANGFUSE", "false").lower() == "true"

# Only initialize if required keys are present
if not os.getenv("LANGFUSE_PUBLIC_KEY") or not os.getenv("LANGFUSE_SECRET_KEY"):
    logger.debug(
        "Langfuse API keys not found - tracing disabled. Set LANGFUSE_PUBLIC_KEY and LANGFUSE_SECRET_KEY to enable"
    )
    langfuse = None
    langfuse_handler = None
elif _langfuse_disabled:
    logger.debug("Langfuse tracing disabled via MCP_CONDUCTOR_LANGFUSE environment variable (set to false)")
    langfuse = None
    langfuse_handler = None
else:
    try:
        import langfuse as _langfuse_module
        from langfuse.langchain import CallbackHandler

        # Initialize Langfuse with constructor arguments (SDK v3 API)
        _langfuse_module.Langfuse(
            public_key=os.getenv("LANGFUSE_PUBLIC_KEY"),
            secret_key=os.getenv("LANGFUSE_SECRET_KEY"),
            host=os.getenv("LANGFUSE_HOST", "https://cloud.langfuse.com"),
        )

        # Get the configured client instance (SDK v3 API)
        langfuse = _langfuse_module.get_client()

        # Initialize the Langfuse handler (no constructor args needed in v3)
        langfuse_handler = CallbackHandler()

        logger.debug("Langfuse observability initialized successfully")
        logger.debug(f"Langfuse host: {os.getenv('LANGFUSE_HOST', 'https://cloud.langfuse.com')}")

    except ImportError:
        logger.debug("Langfuse package not installed - tracing disabled. Install with: pip install langfuse")
        langfuse = None
        langfuse_handler = None
    except Exception as e:
        logger.error(f"Failed to initialize Langfuse: {e}")
        langfuse = None
        langfuse_handler = None

def is_langfuse_available() -> bool:
    """Check if Langfuse is available for agent-level usage."""
    return langfuse_handler is not None