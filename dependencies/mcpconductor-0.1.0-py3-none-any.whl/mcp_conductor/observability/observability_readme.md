# 📊 MCP Conductor Observability

**Production-Grade Monitoring, Tracing, and Analytics for MCP Agents**

The `observability` module provides **enterprise-ready monitoring** for your MCP-powered AI agents. Think of it as the **"flight data recorder"** that tracks every conversation, tool call, and decision your AI makes - essential for debugging, optimization, and business intelligence.

## 📁 Folder Structure

```
mcp_conductor/observability/
├── README.md                   # This documentation
├── __init__.py                 # Module exports
└── observability.py            # Langfuse integration & tracing
```

## 🎯 What Is Observability?

### **Simple Analogy: Restaurant Management System**

Imagine you run a restaurant and want to understand:
- **How many customers came today?** (Traffic)
- **What did they order?** (Requests)  
- **How long did they wait?** (Performance)
- **Were they satisfied?** (Success rates)
- **Which dishes are popular?** (Usage patterns)

**Observability for AI agents is the same**:
- **How many conversations happened?** (Agent usage)
- **What tools were called?** (Tool requests)
- **How long did tasks take?** (Performance metrics)
- **Did tasks succeed or fail?** (Success rates)
- **Which workflows are most common?** (Usage patterns)

```mermaid
graph TB
    subgraph "Your AI Agent"
        A[User Query] --> B[Agent Processing]
        B --> C[Tool Calls]
        C --> D[Results]
    end
    
    subgraph "Observability Layer"
        B --> E[Conversation Tracking]
        C --> F[Tool Usage Metrics]
        D --> G[Performance Analytics]
        E --> H[Langfuse Dashboard]
        F --> H
        G --> H
    end
    
    subgraph "Business Intelligence"
        H --> I[Usage Reports]
        H --> J[Performance Optimization]
        H --> K[Cost Analysis]
        H --> L[User Behavior Insights]
    end
    
    style B fill:#2196f3,color:#fff
    style H fill:#ff9800,color:#fff
    style I fill:#4caf50,color:#fff
```

## 📄 File Documentation

### `__init__.py` - Module Exports

**Purpose**: Clean API for importing observability components.

```python
from mcp_conductor.observability.observability import langfuse, langfuse_handler

__all__ = [
    "langfuse",
    "langfuse_handler",
]
```

### `observability.py` - Langfuse Integration ⭐

**Purpose**: Automatic tracing and monitoring for all MCP agent activities with explicit agent-level control.

#### 🔧 Configuration System

**🆕 NEW: Agent-Level Control**
- **Default Behavior**: Langfuse tracing is **DISABLED** by default
- **Explicit Enable**: Must use `enable_langfuse=True` in agent initialization
- **Environment Aware**: Still respects environment variables when enabled

**Environment-Based Setup**:
```python
# Auto-detects configuration from environment
_langfuse_disabled = os.getenv("MCP_CONDUCTOR_LANGFUSE", "false").lower() == "true"  # Now defaults to false

# Required environment variables
LANGFUSE_PUBLIC_KEY = os.getenv("LANGFUSE_PUBLIC_KEY")
LANGFUSE_SECRET_KEY = os.getenv("LANGFUSE_SECRET_KEY") 
LANGFUSE_HOST = os.getenv("LANGFUSE_HOST", "https://cloud.langfuse.com")
```

**Smart Initialization Logic**:
```python
# Only initialize if API keys are present (regardless of env flag for agent control)
if not LANGFUSE_PUBLIC_KEY or not LANGFUSE_SECRET_KEY:
    langfuse = None
    langfuse_handler = None
elif _langfuse_disabled:
    langfuse = None  
    langfuse_handler = None
else:
    # Initialize Langfuse with SDK v3 API
    langfuse = _langfuse_module.get_client()
    langfuse_handler = CallbackHandler()
```

#### 🚀 Agent Integration

**🔄 Updated: Explicit Control Required**
```python
# ❌ OLD: Automatic tracing (if environment configured)
agent = LangGraphAgent(llm=llm, command="npx", args=["@playwright/mcp"])

# ✅ NEW: Explicit tracing control
agent = LangGraphAgent(
    llm=llm, 
    command="npx", 
    args=["@playwright/mcp"],
    enable_langfuse=True  # 🎯 Must explicitly enable
)
```

## ⚙️ Configuration Guide

### **Step 1: Get Langfuse Account**

1. **Sign up**: Go to [Langfuse Cloud](https://cloud.langfuse.com) or [US Cloud](https://us.cloud.langfuse.com)
2. **Create project**: Set up a new project for MCP Conductor
3. **Get API keys**: Copy your public and secret keys

### **Step 2: Environment Variables**

Add to your `.env` file:
```bash
# Langfuse Configuration
LANGFUSE_PUBLIC_KEY=pk-lf-your-public-key-here
LANGFUSE_SECRET_KEY=sk-lf-your-secret-key-here
LANGFUSE_HOST=https://cloud.langfuse.com        # or https://us.cloud.langfuse.com
MCP_CONDUCTOR_LANGFUSE=false                    # 🆕 Now defaults to false
```

### **Step 3: Verify Setup**

```python
from mcp_conductor.observability import langfuse, langfuse_handler

# Check if observability is available (not the same as enabled)
if langfuse_handler:
    print("✅ Langfuse observability is available!")
    print("💡 Use enable_langfuse=True in agent to activate")
else:
    print("❌ Langfuse observability is not available")
    print("🔧 Check your environment variables")
```

## 🚀 Usage Examples

### **Example 1: Default Behavior (No Tracing)**

```python
from mcp_conductor import LangGraphAgent

# 🎯 NEW: By default, NO Langfuse tracing
agent = LangGraphAgent(
    llm=get_gemini_llm(),
    command="npx",
    args=["@playwright/mcp@latest"]
    # enable_langfuse=False by default
)

async with agent:
    result = await agent.run("Navigate to google.com and search for AI")
    # 🚫 No Langfuse traces generated
```

### **Example 2: Explicit Langfuse Enable**

```python
# 🎯 NEW: Must explicitly enable Langfuse
agent = LangGraphAgent(
    llm=get_gemini_llm(),
    command="npx",
    args=["@playwright/mcp@latest"],
    enable_langfuse=True  # 🆕 Explicit enable required
)

async with agent:
    result = await agent.run("Navigate to google.com and search for AI")
    # ✅ Full Langfuse traces generated
```

### **Example 3: Custom Configuration Provider**

```python
from mcp_conductor import AgentConfigurationProvider

class ProductionConfigurationProvider(AgentConfigurationProvider):
    def __init__(self, user_id, session_id, environment="production"):
        self.user_id = user_id
        self.session_id = session_id  
        self.environment = environment
    
    def get_trace_name(self, query: str, thread_id: str) -> str:
        return f"prod_automation_{self.session_id}"
    
    def get_session_id(self, thread_id: str) -> str:
        return self.session_id
    
    def get_user_id(self) -> str:
        return self.user_id
    
    def get_tags(self, query: str) -> list[str]:
        return ["production", "automation", f"env-{self.environment}"]
    
    def get_metadata(self, query: str, thread_id: str) -> dict:
        return {
            "environment": self.environment,
            "session_id": self.session_id,
            "user_id": self.user_id,
            "query_length": len(query),
            "service": "mcp-conductor"
        }

# Use with explicit Langfuse enable
config = ProductionConfigurationProvider(
    user_id="user-12345",
    session_id="session-67890"
)

agent = LangGraphAgent(
    llm=get_gemini_llm(),
    command="npx", 
    args=["@playwright/mcp@latest"],
    config_provider=config,
    enable_langfuse=True  # 🆕 Explicit enable + config provider
)
```

### **Example 4: ReQon Platform Integration**

```python
class ReQonConfigurationProvider(AgentConfigurationProvider):
    """ReQon-specific observability configuration."""
    
    def __init__(self, recorder_session_id, mcp_session_id, stage, tool_name, user_id=None):
        self.recorder_session_id = recorder_session_id
        self.mcp_session_id = mcp_session_id
        self.stage = stage  # "discovery", "hypothesis", "automation"
        self.tool_name = tool_name
        self.user_id = user_id
    
    def get_trace_name(self, query: str, thread_id: str) -> str:
        return f"reqon_{self.mcp_session_id}_{self.stage}_{self.tool_name}"
    
    def get_session_id(self, thread_id: str) -> str:
        return self.mcp_session_id
    
    def get_user_id(self) -> str:
        return self.user_id
    
    def get_tags(self, query: str) -> list[str]:
        return [
            "reqon-platform",
            f"{self.stage}-stage", 
            f"tool-{self.tool_name}",
            "enterprise"
        ]
    
    def get_metadata(self, query: str, thread_id: str) -> dict:
        return {
            "recorder_session_id": self.recorder_session_id,
            "mcp_session_id": self.mcp_session_id,
            "stage": self.stage,
            "tool_name": self.tool_name,
            "platform": "reqon",
            "service": "reqon-mcp-service",
            "query_complexity": "high" if len(query) > 200 else "medium" if len(query) > 50 else "simple"
        }

# Usage in ReQon MCP Service
reqon_config = ReQonConfigurationProvider(
    recorder_session_id="rec-20241225-001",
    mcp_session_id="mcp-discovery-550e8400",
    stage="discovery",
    tool_name="PageJourneyTool",
    user_id="user-alex-smith-123"
)

agent = LangGraphAgent(
    llm=get_gemini_llm(),
    command="npx",
    args=["@playwright/mcp@latest", "--isolated"],
    config_provider=reqon_config,
    enable_langfuse=True,  # 🆕 Explicit enable for ReQon
    max_steps=500
)
```

### **Example 5: Runtime Control**

```python
# 🆕 NEW: Runtime enable/disable control
agent = LangGraphAgent(
    llm=get_gemini_llm(),
    command="npx",
    args=["@playwright/mcp@latest"],
    config_provider=production_config
    # enable_langfuse=False by default
)

async with agent:
    # No tracing for this operation
    await agent.run("Test operation without tracing")
    
    # Enable tracing for important operations
    agent.enable_tracing()
    
    # This will be traced with config_provider metadata
    result = await agent.run("Critical business operation")
    
    # Disable for cleanup tasks
    agent.disable_tracing()
    await agent.run("Cleanup tasks")
```

### **Example 6: Environment-Based Control**

```python
import os

# 🆕 Environment-based explicit control
enable_tracing = os.getenv("ENABLE_TRACING", "false").lower() == "true"

agent = LangGraphAgent(
    llm=get_gemini_llm(),
    command="npx",
    args=["@playwright/mcp@latest"],
    config_provider=production_config,
    enable_langfuse=enable_tracing  # 🆕 Environment controlled, explicit
)
```

## 📊 What Gets Tracked?

### **Conversation Level**
- **Trace Name**: Custom or auto-generated from config_provider
- **Session ID**: Groups related conversations
- **User ID**: Track individual users
- **Start/End Time**: Conversation duration
- **Total Cost**: LLM API costs
- **Success/Failure**: Overall outcome

### **Tool Call Level**
- **Tool Name**: Which MCP tool was called
- **Input Parameters**: What data was sent
- **Execution Time**: How long it took
- **Success/Failure**: Did it work?
- **Output Size**: Response data volume
- **Error Messages**: Detailed failure info

### **Performance Metrics**
- **Response Time**: End-to-end latency
- **Token Usage**: Input/output token counts
- **Tool Call Frequency**: Most used tools
- **Error Rates**: Failure percentages
- **Cost Analytics**: Spending per user/session

### **Custom Business Metrics**
- **Environment**: dev/staging/production
- **Feature Usage**: Which capabilities are used
- **User Behavior**: Usage patterns
- **A/B Testing**: Compare different approaches

## 🎯 Langfuse Dashboard Features

### **Real-Time Monitoring**
```
📊 Live Dashboard View:
┌─────────────────────────────────────────────┐
│ MCP Conductor - Production Dashboard        │
├─────────────────────────────────────────────┤
│ 🟢 Active Sessions: 23                     │
│ ⚡ Avg Response Time: 2.3s                 │
│ 🎯 Success Rate: 97.8%                     │
│ 💰 Today's Cost: $12.45                    │
├─────────────────────────────────────────────┤
│ Top Tools Used:                            │
│ 1. playwright_navigate (145 calls)         │
│ 2. playwright_click (89 calls)             │
│ 3. playwright_screenshot (67 calls)        │
└─────────────────────────────────────────────┘
```

### **Trace Explorer**
- **Conversation Flow**: See every step of agent reasoning
- **Tool Call Timeline**: Visual execution sequence  
- **Error Analysis**: Pinpoint exactly where failures occur
- **Performance Bottlenecks**: Identify slow operations

### **Analytics & Reports**
- **Usage Trends**: Daily/weekly/monthly patterns
- **Cost Analysis**: Spending by user, session, or feature
- **Performance Reports**: Response times and success rates
- **User Insights**: Most active users and use cases

## 🔧 Advanced Configuration

### **Production Environment Setup**

```python
# Production-optimized configuration
import os

# Environment-specific settings
if os.getenv("ENVIRONMENT") == "production":
    # Production Langfuse instance
    os.environ["LANGFUSE_HOST"] = "https://langfuse.company.com"
    os.environ["LANGFUSE_PUBLIC_KEY"] = "pk-prod-..."
    os.environ["LANGFUSE_SECRET_KEY"] = "sk-prod-..."
    enable_tracing = True  # Enable for production monitoring
    
elif os.getenv("ENVIRONMENT") == "staging":
    # Staging environment
    os.environ["LANGFUSE_HOST"] = "https://staging-langfuse.company.com"
    os.environ["LANGFUSE_PUBLIC_KEY"] = "pk-staging-..."
    enable_tracing = True  # Enable for staging testing
    
else:
    # Development - typically disabled unless debugging
    enable_tracing = False

agent = LangGraphAgent(
    llm=production_llm,
    client=production_client,
    config_provider=production_config,
    enable_langfuse=enable_tracing  # 🆕 Environment-based explicit control
)
```

## 🚨 Troubleshooting

### **Common Issues & Solutions**

#### **1. Observability Not Working**
```python
# Debug checklist
from mcp_conductor.observability import langfuse, langfuse_handler

print(f"Langfuse client: {langfuse}")
print(f"Langfuse handler: {langfuse_handler}")
print(f"Public key set: {bool(os.getenv('LANGFUSE_PUBLIC_KEY'))}")
print(f"Secret key set: {bool(os.getenv('LANGFUSE_SECRET_KEY'))}")
print(f"Agent enable_langfuse: {agent.enable_langfuse}")  # 🆕 Check agent setting
```

#### **2. Missing Traces**
```bash
# Check environment variables
echo $LANGFUSE_PUBLIC_KEY
echo $LANGFUSE_SECRET_KEY  
echo $LANGFUSE_HOST
echo $MCP_CONDUCTOR_LANGFUSE

# 🆕 Check agent configuration
# Make sure enable_langfuse=True is set in agent initialization
```

#### **3. Performance Issues**
```python
# Selective tracing for high-volume scenarios
class LightweightConfigurationProvider(AgentConfigurationProvider):
    def get_metadata(self, query: str, thread_id: str) -> dict:
        # Minimal metadata for performance
        return {
            "session_id": self.session_id,
            "timestamp": datetime.utcnow().isoformat()
        }

# Only enable tracing for critical operations
agent = LangGraphAgent(
    llm=llm,
    command="npx",
    args=["@playwright/mcp@latest"],
    config_provider=LightweightConfigurationProvider(),
    enable_langfuse=False  # 🆕 Default disabled for performance
)

# Enable only for important operations
agent.enable_tracing()
await agent.run("Critical operation")
agent.disable_tracing()
```

## 📈 Business Value

### **For Developers** 👨‍💻
- **Faster Debugging**: See exactly where agents fail
- **Performance Optimization**: Identify slow operations
- **Usage Analytics**: Understand how agents are used
- **Quality Assurance**: Monitor success rates

### **For Product Teams** 📊
- **User Behavior**: Which features are popular
- **Cost Management**: Optimize LLM spending
- **A/B Testing**: Compare different agent approaches
- **ROI Measurement**: Quantify automation value

### **For Enterprise** 🏢
- **Compliance**: Audit trails for agent decisions
- **Security**: Monitor for unusual patterns
- **Scalability**: Plan for growth based on usage
- **Cost Control**: Detailed spending breakdowns

## 🔮 Future Enhancements

### **Planned Features**
- **Custom Dashboards**: Build domain-specific views
- **Alert System**: Notify on errors or anomalies
- **Integration APIs**: Connect to existing monitoring
- **ML Insights**: Predict performance issues

### **Advanced Analytics**
- **Agent Performance Scoring**: Rate agent effectiveness
- **User Satisfaction Metrics**: Track success indicators
- **Predictive Analytics**: Forecast usage and costs
- **Anomaly Detection**: Automatic issue identification

## 💡 Key Takeaways

### **🆕 NEW: Explicit Control Model**
- **Default Disabled**: Langfuse tracing is OFF by default
- **Explicit Enable**: Must use `enable_langfuse=True` to activate
- **Runtime Control**: `enable_tracing()` and `disable_tracing()` methods
- **Configuration Driven**: All metadata comes from config_provider

### **What Observability Does** 🎯
- **Explicit tracking** when enabled at agent level
- **Production-grade monitoring** with enterprise features
- **Custom metadata** for business intelligence
- **Performance optimization** through detailed analytics

### **Why It Matters** 💪
- **Privacy First**: No automatic tracing without explicit consent
- **Performance Aware**: Zero overhead when disabled
- **Enterprise Ready**: Flexible control for different environments
- **Developer Friendly**: Clear enable/disable semantics

### **The Big Picture** 🌟
The new explicit control model gives you **complete control** over when and how your AI agents are monitored. **Privacy by default**, **performance by design**, and **enterprise-ready** observability when you need it.

It's the difference between "always watching" and "watch when I tell you to"! 🔐📊