"""
Dynamic system prompt generation for AI agents.

This module provides templates and builders for creating system prompts
that dynamically include tool descriptions and instructions.
"""

# Internal templates and builders - not exported
# These are used internally by agents

__all__ = []