# 💬 MCP Conductor Prompts

**Dynamic System Prompt Generation for AI Agents**

The `prompts` module is the **"instruction manual writer"** for AI agents. It dynamically creates system prompts that tell the AI what tools are available and how to use them effectively.

## 📁 Folder Structure

```
mcp_conductor/prompts/
├── __init__.py                 # Empty module (no exports needed)
├── templates.py                # System prompt templates  
└── system_prompt_builder.py   # Dynamic prompt generation engine
```

## 🏗️ Architecture Overview

```mermaid
graph TB
    subgraph "MCP Tools Discovery"
        A[Playwright MCP] --> D[Tool List]
        B[Filesystem MCP] --> D
        C[Custom MCP] --> D
    end
    
    subgraph "Prompt Generation Engine"
        D --> E[generate_tool_descriptions]
        E --> F[build_system_prompt_content]
        F --> G[create_system_message]
    end
    
    subgraph "Template Selection"
        H[DEFAULT_SYSTEM_PROMPT_TEMPLATE] --> F
        I[SERVER_MANAGER_TEMPLATE] --> F
        J[User Custom Template] --> F
    end
    
    subgraph "AI Agent"
        G --> K[LangChain Agent]
        G --> L[LangGraph Agent]
    end
    
    style E fill:#ff9800,color:#fff
    style F fill:#2196f3,color:#fff
    style G fill:#4caf50,color:#fff
    style K fill:#9c27b0,color:#fff
```

## 🎯 What Do Prompts Actually Do?

### **Simple Analogy: Writing Job Instructions**

Imagine you're a manager writing instructions for a new employee:

```
❌ BAD Instructions:
"Do your job well. You have tools. Use them."

✅ GOOD Instructions:
"You are a web automation specialist. You have these tools:

- navigate_to_page: Go to any website (parameter: url)
- click_element: Click on page elements (parameter: selector)  
- fill_form: Enter text in forms (parameters: field, text)
- take_screenshot: Capture page images (no parameters)

When a user asks you to automate a website:
1. Think about what steps are needed
2. Use the appropriate tools in sequence
3. Provide clear feedback on what you did"
```

**The prompts module does the same thing for AI agents**:

```
MCP Tools Available:
- playwright_navigate(url: str)
- playwright_click(selector: str)
- filesystem_read(path: str)

Prompts Module:
"You are a helpful AI assistant. You have access to these tools:
- playwright_navigate: Navigate to a webpage. Input: url (string)
- playwright_click: Click an element. Input: selector (string) 
- filesystem_read: Read file contents. Input: path (string)

Use the following format when working:
1. Think about what to do
2. Use the appropriate tool
3. Observe the result
4. Continue until task is complete"
```

## 📄 File Documentation

### `__init__.py` - Empty Module

**Purpose**: No exports needed since templates and builders are used internally.

```python
# Empty file - prompts are internal implementation details
```

---

### `templates.py` - System Prompt Templates ⭐

**Purpose**: Pre-written prompt templates that can be filled with dynamic tool information.

#### 🎯 Core Templates

**1. DEFAULT_SYSTEM_PROMPT_TEMPLATE**
```python
DEFAULT_SYSTEM_PROMPT_TEMPLATE = """You are a helpful AI assistant.
You have access to the following tools:

{tool_descriptions}

Use the following format:

Question: the input question you must answer
Thought: you should always think about what to do
Action: the action to take, should be one of the available tools
Action Input: the input to the action
Observation: the result of the action
... (this Thought/Action/Action Input/Observation can repeat N times)
Thought: I now know the final answer
Final Answer: the final answer to the original input question"""
```

**What it does**:
- Basic ReAct (Reasoning + Acting) pattern
- `{tool_descriptions}` gets replaced with actual tool info
- Teaches AI the step-by-step thinking process

**2. SERVER_MANAGER_SYSTEM_PROMPT_TEMPLATE**
```python
SERVER_MANAGER_SYSTEM_PROMPT_TEMPLATE = """You are a helpful assistant designed
to interact with MCP (Model Context Protocol) servers. You can manage connections
to different servers and use the tools provided by the currently active server.

Important: The available tools change dynamically based on which server is active.

- When you connect to a server using 'connect_to_mcp_server', that server's tools are automatically added
- When you disconnect using 'disconnect_from_mcp_server', the server's tools are removed
- The tool list below will automatically update when you connect/disconnect from servers

Here are the tools currently available to you:
{tool_descriptions}
"""
```

**What it does**:
- Advanced mode for managing multiple MCP servers
- Explains dynamic tool loading/unloading
- Used when `use_server_manager=True`

#### 🎨 Template Features

**Dynamic Tool Placeholder**:
- `{tool_descriptions}` is replaced with actual tool information
- Format: `- tool_name: tool description`
- Handles escaping of special characters

**Flexible Content**:
- Templates can be overridden by users
- Support for additional instructions
- Graceful handling of missing placeholders

---

### `system_prompt_builder.py` - Dynamic Prompt Engine ⭐

**Purpose**: The "smart assembler" that takes tools and templates and creates complete system prompts.

#### 🎯 Core Functions

**1. generate_tool_descriptions()**
```python
def generate_tool_descriptions(
    tools: list[BaseTool], 
    disallowed_tools: list[str] | None = None
) -> list[str]:
    """Convert LangChain tools into formatted descriptions."""
    
    disallowed_set = set(disallowed_tools or [])
    tool_descriptions_list = []
    
    for tool in tools:
        if tool.name in disallowed_set:
            continue
            
        # Escape curly braces for formatting safety
        escaped_desc = tool.description.replace("{", "{{").replace("}", "}}")
        description = f"- {tool.name}: {escaped_desc}"
        tool_descriptions_list.append(description)
        
    return tool_descriptions_list
```

**Example Output**:
```
- playwright_navigate: Navigate to a webpage and wait for it to load
- playwright_click: Click on an element specified by CSS selector  
- filesystem_read: Read the contents of a file from the filesystem
```

**2. build_system_prompt_content()**
```python
def build_system_prompt_content(
    template: str, 
    tool_description_lines: list[str], 
    additional_instructions: str | None = None
) -> str:
    """Assemble the final prompt from template and descriptions."""
    
    tool_descriptions_block = "\n".join(tool_description_lines)
    
    # Safety check for missing placeholder
    if "{tool_descriptions}" not in template:
        print("Warning: '{tool_descriptions}' placeholder not found")
        system_prompt_content = template + "\n\nAvailable tools:\n" + tool_descriptions_block
    else:
        system_prompt_content = template.format(tool_descriptions=tool_descriptions_block)
    
    if additional_instructions:
        system_prompt_content += f"\n\n{additional_instructions}"
    
    return system_prompt_content
```

**3. create_system_message() - The Main Function**
```python
def create_system_message(
    tools: list[BaseTool],
    system_prompt_template: str,
    server_manager_template: str,
    use_server_manager: bool,
    disallowed_tools: list[str] | None = None,
    user_provided_prompt: str | None = None,
    additional_instructions: str | None = None,
) -> SystemMessage:
    """Create the final SystemMessage for the AI agent."""
    
    # 1. User override takes priority
    if user_provided_prompt:
        return SystemMessage(content=user_provided_prompt)
    
    # 2. Select appropriate template
    template = server_manager_template if use_server_manager else system_prompt_template
    
    # 3. Generate tool descriptions
    tool_descriptions = generate_tool_descriptions(tools, disallowed_tools)
    
    # 4. Build final content
    final_content = build_system_prompt_content(
        template=template,
        tool_description_lines=tool_descriptions,
        additional_instructions=additional_instructions
    )
    
    return SystemMessage(content=final_content)
```

## 🚀 Usage Examples

### Basic Prompt Generation

```python
from mcp_conductor.prompts.system_prompt_builder import create_system_message
from mcp_conductor.prompts.templates import DEFAULT_SYSTEM_PROMPT_TEMPLATE

# Tools from MCP servers
tools = [
    Tool(name="navigate", description="Go to a webpage"),
    Tool(name="click", description="Click an element"),
    Tool(name="screenshot", description="Take a screenshot")
]

# Generate system message
system_msg = create_system_message(
    tools=tools,
    system_prompt_template=DEFAULT_SYSTEM_PROMPT_TEMPLATE,
    server_manager_template="",  # Not used
    use_server_manager=False
)

print(system_msg.content)
```

**Output**:
```
You are a helpful AI assistant.
You have access to the following tools:

- navigate: Go to a webpage
- click: Click an element  
- screenshot: Take a screenshot

Use the following format:

Question: the input question you must answer
Thought: you should always think about what to do
Action: the action to take, should be one of the available tools
...
```

### Custom Template Example

```python
# Custom template for specific use case
CUSTOM_TEMPLATE = """You are a web testing expert.
Available testing tools:

{tool_descriptions}

When testing websites:
1. Always start by navigating to the page
2. Take screenshots for documentation
3. Test user interactions systematically
4. Report any issues found
"""

system_msg = create_system_message(
    tools=tools,
    system_prompt_template=CUSTOM_TEMPLATE,
    server_manager_template="",
    use_server_manager=False,
    additional_instructions="Focus on accessibility testing."
)
```

### Tool Filtering Example

```python
# Exclude certain tools from the agent
system_msg = create_system_message(
    tools=all_available_tools,
    system_prompt_template=DEFAULT_SYSTEM_PROMPT_TEMPLATE,
    server_manager_template="",
    use_server_manager=False,
    disallowed_tools=["dangerous_tool", "admin_only_tool"]
)
```

### Server Manager Mode

```python
# For agents that manage multiple MCP servers
system_msg = create_system_message(
    tools=current_tools,
    system_prompt_template=DEFAULT_SYSTEM_PROMPT_TEMPLATE,
    server_manager_template=SERVER_MANAGER_SYSTEM_PROMPT_TEMPLATE,
    use_server_manager=True  # Uses server manager template
)
```

## 🔧 Integration with Agents

### Traditional Agent Integration

```python
# In mcp_conductor/agent.py
class Agent:
    async def _create_system_message_from_tools(self, tools: list[BaseTool]) -> None:
        self._system_message = create_system_message(
            tools=tools,
            system_prompt_template=self.system_prompt_template_override or DEFAULT_SYSTEM_PROMPT_TEMPLATE,
            server_manager_template=SERVER_MANAGER_SYSTEM_PROMPT_TEMPLATE,
            use_server_manager=self.use_server_manager,
            disallowed_tools=self.disallowed_tools,
            user_provided_prompt=self.system_prompt,
            additional_instructions=self.additional_instructions,
        )
```

### LangGraph Agent Integration

```python
# In mcp_conductor/langgraph_agent.py  
class LangGraphAgent:
    async def _create_system_message_content_from_tools(self, tools: list[BaseTool]) -> None:
        system_message = create_system_message(
            tools=tools,
            system_prompt_template=default_template,
            server_manager_template=SERVER_MANAGER_SYSTEM_PROMPT_TEMPLATE,
            use_server_manager=self.use_server_manager,
            disallowed_tools=self.disallowed_tools,
            user_provided_prompt=self.system_prompt,
            additional_instructions=self.additional_instructions,
        )
        
        self._system_message_content = system_message.content
```

## 🎯 Real-World Prompt Examples

### Example 1: Browser Automation Agent

**Input Tools**:
- `playwright_navigate(url: str)`
- `playwright_click(selector: str)`  
- `playwright_fill(selector: str, text: str)`
- `playwright_screenshot()`

**Generated Prompt**:
```
You are a helpful AI assistant.
You have access to the following tools:

- playwright_navigate: Navigate to a webpage and wait for it to load completely
- playwright_click: Click on an element specified by CSS selector
- playwright_fill: Fill out a form field with the specified text
- playwright_screenshot: Take a screenshot of the current page

Use the following format:

Question: the input question you must answer
Thought: you should always think about what to do
Action: the action to take, should be one of the available tools
Action Input: the input to the action
Observation: the result of the action
... (this Thought/Action/Action Input/Observation can repeat N times)
Thought: I now know the final answer
Final Answer: the final answer to the original input question
```

### Example 2: File Operations Agent

**Input Tools**:
- `filesystem_read(path: str)`
- `filesystem_write(path: str, content: str)`
- `filesystem_list(directory: str)`

**Generated Prompt**:
```
You are a helpful AI assistant.
You have access to the following tools:

- filesystem_read: Read the contents of a file from the local filesystem
- filesystem_write: Write content to a file on the local filesystem  
- filesystem_list: List all files and directories in the specified path

[... rest of template ...]
```

### Example 3: Multi-Server Manager

**Server Manager Mode Prompt**:
```
You are a helpful assistant designed to interact with MCP servers. 
You can manage connections to different servers and use tools dynamically.

Important: The available tools change based on which server is active.

- When you connect to a server using 'connect_to_mcp_server', tools are added
- When you disconnect using 'disconnect_from_mcp_server', tools are removed
- The tool list below updates automatically

Here are the tools currently available to you:
- connect_to_mcp_server: Connect to an MCP server by name
- disconnect_from_mcp_server: Disconnect from an MCP server
- list_mcp_servers: Show all available MCP servers
```

## 🔧 Advanced Features

### Character Escaping

```python
# Handles tools with special characters in descriptions
tool_with_braces = Tool(
    name="format_template", 
    description="Format template with {variables} and {{escaped}} braces"
)

# Becomes:
"- format_template: Format template with {{variables}} and {{{{escaped}}}} braces"
```

### Error Handling

```python
# Missing placeholder fallback
template_without_placeholder = "You are an AI assistant. Be helpful."

# Builder detects missing {tool_descriptions} and appends tools anyway:
"You are an AI assistant. Be helpful.

Available tools:
- tool1: Description 1
- tool2: Description 2"
```

### Priority System

```python
# Priority order for prompt content:
# 1. user_provided_prompt (complete override)
# 2. Selected template + tools + additional_instructions  
# 3. Fallback with tools appended if placeholder missing

if user_provided_prompt:
    return SystemMessage(content=user_provided_prompt)  # Highest priority
else:
    # Use template system with tool injection
```

## 💡 Key Takeaways

### **What Prompts Do** 🎯
- **Transform MCP tools into AI instructions** that the agent can understand
- **Provide consistent formatting** for tool descriptions across different MCP servers
- **Enable dynamic prompt generation** as tools are added/removed
- **Support multiple prompt styles** for different use cases

### **Why They Matter** 💪
- **AI Agent Effectiveness**: Good prompts = better tool usage
- **Dynamic Flexibility**: Prompts adapt as tools change
- **User Customization**: Users can override with their own prompts
- **Consistency**: Standardized format across all MCP integrations

### **The Big Picture** 🌟
The prompts module is the **"communication bridge"** between:
- **MCP Tools** (what's available)
- **AI Agents** (what they understand)
- **Users** (what they want to accomplish)

It ensures that AI agents always have up-to-date, clear instructions about what tools they can use and how to use them effectively! 📝✨