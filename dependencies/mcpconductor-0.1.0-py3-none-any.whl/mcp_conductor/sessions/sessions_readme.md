# 🔗 MCP Conductor Sessions

**Individual MCP Server Connection Management - The Communication Bridge**

The `sessions` module manages **individual MCP server connections**, handling authentication, initialization, and tool discovery. Think of it as the **"phone line"** that maintains a conversation with a single MCP server.

## 📁 Folder Structure

```
mcp_conductor/sessions/
├── README.md                   # This documentation
├── __init__.py                 # Module exports
└── session.py                  # Individual session management
```

## 🎯 What Does a Session Do?

### **Simple Analogy: Phone Call Manager**

```
📞 You want to call a friend (MCP Server)
   ↓
📱 Session Manager handles the call:
   • Dials the number (connects)
   • Maintains the connection
   • Translates your words (protocol handling)
   • Handles dropped calls (reconnection)
   • Hangs up properly (cleanup)
   ↓
🗣️ You have a clear conversation
```

**MCPSession does the same for MCP servers**:
- **Connects** to individual MCP servers
- **Maintains** the connection health
- **Discovers** available tools/resources/prompts
- **Executes** tool calls
- **Handles** errors and reconnection

## 🏗️ Architecture Overview

```mermaid
graph TB
    subgraph "Session Layer"
        A[MCPSession] --> B[Connection Management]
        A --> C[Tool Discovery]
        A --> D[Operation Execution]
    end
    
    subgraph "Transport Layer"
        B --> E[BaseConnector]
        E --> F[StdioConnector]
        F --> G[ConnectionManager]
    end
    
    subgraph "MCP Server"
        G --> H[MCP Process]
        H --> I[Tools]
        H --> J[Resources]  
        H --> K[Prompts]
    end
    
    subgraph "Operations"
        D --> L[call_tool]
        D --> M[list_tools]
        D --> N[read_resource]
        D --> O[get_prompt]
    end
    
    style A fill:#2196f3,color:#fff
    style B fill:#ff9800,color:#fff
    style D fill:#4caf50,color:#fff
```

## 📄 File Documentation

### `session.py` - Individual Session Management ⭐

**Purpose**: Manages the complete lifecycle of a connection to a single MCP server.

#### 🎯 Core Responsibilities

1. **🔌 Connection Lifecycle**
   - Establish connection through connectors
   - Monitor connection health
   - Handle automatic reconnection
   - Clean resource cleanup

2. **🔍 Capability Discovery**
   - Initialize MCP session
   - Discover available tools
   - List resources and prompts
   - Cache capability information

3. **⚡ Operation Execution**
   - Execute tool calls with parameters
   - Read resources by URI
   - Get prompts with arguments
   - Handle timeouts and errors

4. **🛡️ Error Management**
   - Connection loss detection
   - Automatic recovery attempts
   - Graceful degradation
   - Resource cleanup on failure

## 🔧 Key Methods

### **MCPSession Class**

```python
class MCPSession:
    # Lifecycle management
    async def connect() -> None
    async def disconnect() -> None
    async def initialize() -> dict[str, Any]
    
    # Property checks
    @property
    def is_connected() -> bool
    
    # MCP operations
    async def call_tool(name: str, arguments: dict) -> CallToolResult
    async def list_tools() -> list[Tool]
    async def list_resources() -> list[Resource]
    async def read_resource(uri: AnyUrl) -> ReadResourceResult
    async def list_prompts() -> list[Prompt]
    async def get_prompt(name: str, arguments: dict) -> GetPromptResult
```

## 💻 Usage Examples

### **Basic Session Usage**

```python
from mcp_conductor.sessions import MCPSession
from mcp_conductor.connectors import StdioConnector

# Create connector for MCP server
connector = StdioConnector(
    command="npx",
    args=["@playwright/mcp@latest"]
)

# Create session
session = MCPSession(connector)

# Use session
async with session:
    # Discover available tools
    tools = await session.list_tools()
    print(f"Available tools: {[t.name for t in tools]}")
    
    # Execute a tool
    result = await session.call_tool("navigate", {"url": "https://example.com"})
    print(f"Result: {result}")
```

### **Manual Connection Management**

```python
# Manual lifecycle management
session = MCPSession(connector, auto_connect=False)

try:
    # Connect and initialize
    await session.connect()
    session_info = await session.initialize()
    
    # Use the session
    tools = await session.list_tools()
    
    # Execute operations
    for tool in tools[:3]:  # Try first 3 tools
        try:
            result = await session.call_tool(tool.name, {})
            print(f"✅ {tool.name}: Success")
        except Exception as e:
            print(f"❌ {tool.name}: {e}")
            
finally:
    await session.disconnect()
```

### **Resource and Prompt Operations**

```python
async with session:
    # Work with resources
    resources = await session.list_resources()
    for resource in resources:
        content = await session.read_resource(resource.uri)
        print(f"Resource {resource.name}: {len(content.contents)} items")
    
    # Work with prompts
    prompts = await session.list_prompts()
    for prompt in prompts:
        if prompt.arguments:
            # Prompt needs arguments
            result = await session.get_prompt(prompt.name, {"param": "value"})
        else:
            # No arguments needed
            result = await session.get_prompt(prompt.name)
        print(f"Prompt {prompt.name}: {len(result.messages)} messages")
```

### **Error Handling and Recovery**

```python
async def robust_session_usage():
    session = MCPSession(connector)
    
    try:
        async with session:
            # Check connection health
            if not session.is_connected:
                print("⚠️ Session not connected")
                return
            
            # Perform operations with error handling
            try:
                result = await session.call_tool("risky_operation", {"param": "test"})
                print(f"✅ Success: {result}")
            except Exception as e:
                print(f"❌ Tool failed: {e}")
                
                # Check if connection is still alive
                if session.is_connected:
                    print("🔄 Connection still good, trying different approach")
                    # Try alternative operation
                else:
                    print("💔 Connection lost")
                    return
                    
    except Exception as e:
        print(f"💥 Session error: {e}")
```

## 🔄 Session Lifecycle

### **Connection Flow**

```mermaid
sequenceDiagram
    participant App as Application
    participant Session as MCPSession
    participant Connector as Connector
    participant Server as MCP Server
    
    App->>Session: MCPSession(connector)
    App->>Session: async with session (or connect())
    Session->>Connector: connect()
    Connector->>Server: Launch/Connect
    Server->>Connector: Connection ready
    Connector->>Session: Connected
    
    Session->>Server: initialize()
    Server->>Session: Capabilities & info
    Session->>Session: Cache tools/resources/prompts
    Session->>App: Ready for operations
    
    Note over App,Server: Normal Operations
    App->>Session: call_tool()
    Session->>Server: Execute tool
    Server->>Session: Tool result
    Session->>App: Parsed result
    
    Note over App,Server: Cleanup
    App->>Session: disconnect() or __aexit__
    Session->>Connector: disconnect()
    Connector->>Server: Terminate/close
```

### **Auto-Recovery Flow**

```mermaid
sequenceDiagram
    participant Session as MCPSession
    participant Connector as Connector
    participant Server as MCP Server
    
    Session->>Server: call_tool()
    Server--xSession: Connection lost
    Session->>Session: Detect disconnection
    
    alt Auto-connect enabled
        Session->>Connector: reconnect()
        Connector->>Server: Re-establish connection
        Server->>Connector: Connected
        Session->>Server: Retry tool call
        Server->>Session: Success
    else Auto-connect disabled
        Session->>Session: Raise ConnectionError
    end
```

## 🎯 Integration with Other Components

### **With Connectors**

```python
# Session uses connectors for transport
session = MCPSession(stdio_connector)
await session.connect()  # Delegates to connector.connect()
```

### **With Clients** 

```python
# Client manages multiple sessions
client = MCPClient.from_config_file("config.json")
await client.create_all_sessions()  # Creates MCPSession for each server

# Access individual sessions
browser_session = client.get_session("browser")
file_session = client.get_session("files")
```

### **With Adapters**

```python
# Adapters convert session tools to LangChain format
adapter = ToolAdapter()
langchain_tools = await adapter.create_tools(session)

# Each tool keeps reference to its session
for tool in langchain_tools:
    tool.tool_session  # References the MCPSession
```

### **With Agents**

```python
# Agents use sessions indirectly through adapters
agent = LangGraphAgent(llm=llm, client=client)
# Agent gets tools from all sessions via client → adapter conversion
```

## 🔍 Session Health Monitoring

### **Connection Status**

```python
# Check session health
if session.is_connected:
    print("🟢 Session is healthy")
else:
    print("🔴 Session disconnected")

# Get session info
if session.session_info:
    print(f"Server capabilities: {session.session_info}")
else:
    print("⚠️ Session not initialized")
```

### **Tool Discovery Status**

```python
# Check what's available
try:
    tools = await session.list_tools()
    resources = await session.list_resources()
    prompts = await session.list_prompts()
    
    print(f"📊 Session inventory:")
    print(f"  🛠️ Tools: {len(tools)}")
    print(f"  📄 Resources: {len(resources)}")
    print(f"  💬 Prompts: {len(prompts)}")
    
except Exception as e:
    print(f"❌ Discovery failed: {e}")
```

## 🔧 Configuration Options

### **Session Creation**

```python
# Basic session
session = MCPSession(connector)

# With auto-connect disabled
session = MCPSession(connector, auto_connect=False)

# Session will auto-connect when needed
await session.call_tool("navigate", {"url": "https://example.com"})
```

### **Timeout Configuration**

```python
# Tool calls with timeout
result = await session.call_tool(
    "long_running_tool", 
    {"param": "value"},
    read_timeout_seconds=timedelta(seconds=60)
)
```

## 💡 Best Practices

### **✅ Do:**
- Use async context managers (`async with session`)
- Check `is_connected` before critical operations
- Handle connection failures gracefully
- Initialize sessions before using tools
- Clean up with proper disconnection

### **❌ Don't:**
- Forget to call `initialize()` after connecting
- Ignore connection health checks
- Leave sessions open without cleanup
- Assume tools are always available
- Block on long-running operations without timeouts

### **Resource Management Pattern**

```python
# ✅ Good: Proper cleanup
async def good_session_usage():
    session = MCPSession(connector)
    try:
        await session.connect()
        await session.initialize()
        return await do_work_with_session(session)
    finally:
        await session.disconnect()

# ✅ Better: Context manager
async def better_session_usage():
    async with MCPSession(connector) as session:
        return await do_work_with_session(session)
```

## 🚨 Common Issues & Solutions

### **Session Won't Connect**

```python
# Debug connection issues
try:
    await session.connect()
except Exception as e:
    print(f"Connection failed: {e}")
    print(f"Connector type: {type(session.connector)}")
    print(f"Server command: {session.connector.command if hasattr(session.connector, 'command') else 'N/A'}")
```

### **Tools Not Available**

```python
# Check initialization status
if not session.session_info:
    print("⚠️ Session not initialized, calling initialize()")
    await session.initialize()

tools = await session.list_tools()
if not tools:
    print("❌ No tools available from this server")
```

### **Connection Drops**

```python
# Handle connection drops
if not session.is_connected:
    print("🔄 Reconnecting...")
    await session.connect()
    await session.initialize()  # Re-discover capabilities
```

## 💡 Key Takeaways

### **What Sessions Do** 🎯
- **Manage individual MCP server connections**
- **Handle connection lifecycle** (connect, initialize, disconnect)
- **Discover server capabilities** (tools, resources, prompts)
- **Execute MCP operations** with error handling

### **Why They Matter** 💪
- **Abstraction**: Hide connection complexity from higher layers
- **Reliability**: Auto-recovery and health monitoring
- **Simplicity**: Clean async interface for MCP operations
- **Resource Safety**: Proper cleanup and lifecycle management

### **The Big Picture** 🌟
Sessions are the **"communication bridge"** between your application and individual MCP servers. They handle all the low-level details so you can focus on using the tools!

Think of them as **"dedicated phone lines"** - each session maintains a clear, reliable connection to one MCP server! 📞✨